package com.zenix.ui;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.Zenix;
import com.zenix.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/** ZENIX ClickGUI: category sidebar, search, module cards with expandable settings, animated switches and sliders. */
public class ClickGui extends Screen {
  static final class Hit { int x, y, w, h, kind; Module m; Setting s; Category c; }
  static final int K_CAT = 0, K_CARD = 1, K_BOOL = 2, K_SLIDER = 3, K_MODE = 4, K_BIND = 5, K_BOTS = 6;

  Category sel; String query = ""; Module open, binding; Setting drag; Hit dragHit;
  float scroll, scrollTarget, fade, contentH;
  long last;
  final Map<Module, Float> expand = new HashMap<>(), tog = new HashMap<>();
  final Map<Setting, Float> sanim = new HashMap<>();
  final List<Hit> hits = new ArrayList<>();
  int vx, vy, vw, vh;

  public ClickGui() { super(Text.literal("ZENIX")); }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}
  @Override public boolean shouldPause() { return false; }

  int pw() { return Math.min(width - 12, 780); } int ph() { return Math.min(height - 12, 450); }
  int px() { return (width - pw()) / 2; } int py() { return (height - ph()) / 2; }

  Hit hit(int kind, int x, int y, int w, int h, Module m, Setting s, Category c) {
    Hit t = new Hit(); t.kind = kind; t.x = x; t.y = y; t.w = w; t.h = h; t.m = m; t.s = s; t.c = c; hits.add(t); return t;
  }
  int f(int col) { return Colors.alpha(col, fade); }
  void small(DrawContext c, String t, int x, int y, int col) {
    c.getMatrices().push(); c.getMatrices().translate(x, y, 0); c.getMatrices().scale(0.75f, 0.75f, 1f);
    c.drawText(textRenderer, Fnt.t(t), 0, 0, col, false); c.getMatrices().pop();
  }

  static int extraHeight(Module m) {
    if (m.planned) return 0;
    int h = 8;
    for (Setting s : m.settings) h += (s.bool || s.isMode()) ? 22 : 30;
    return h + 22;
  }

  @Override public void render(DrawContext c, int mx, int my, float d) {
    long now = System.nanoTime(); float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f); last = now;
    boolean anim = Zenix.clickgui.get("Animations").on(); float sp = anim ? 1f : 60f;
    fade = Draw.approach(fade, 1f, dt, 14f * sp);
    scroll = Draw.approach(scroll, scrollTarget, dt, 16f * sp);
    hits.clear();
    c.fill(0, 0, width, height, f(0xB0050309));

    int x = px(), y = py(), w = pw(), h = ph(), side = 132;
    Draw.rrect(c, x - 1, y - 1, w + 2, h + 2, 8, f(Theme.BORDER));
    Draw.rrect(c, x, y, w, h, 8, f(Theme.BG));
    Draw.rrect(c, x, y, side, h, 8, f(Theme.SIDEBAR));
    c.fill(x + side - 8, y, x + side, y + h, f(Theme.SIDEBAR));

    // logo
    c.getMatrices().push(); c.getMatrices().translate(x + 14, y + 14, 0); c.getMatrices().scale(1.6f, 1.6f, 1f);
    c.drawText(textRenderer, Fnt.t("ZENIX"), 0, 0, f(Theme.accentLight()), true); c.getMatrices().pop();
    small(c, "CLIENT  1.21.4", x + 15, y + 36, f(Theme.DIM));

    // categories
    int cy = y + 56;
    cy = categoryRow(c, mx, my, x + 8, cy, side - 16, null, "All");
    for (Category cat : Category.values()) cy = categoryRow(c, mx, my, x + 8, cy, side - 16, cat, cat.title());
    // Bots entry
    int by = y + h - 56;
    boolean hb = Draw.in(mx, my, x + 8, by, side - 16, 24);
    Draw.rrect(c, x + 8, by, side - 16, 24, 6, f(hb ? Theme.accentDark() : Theme.FIELD), f(Theme.BORDER));
    c.drawCenteredTextWithShadow(textRenderer, Fnt.t("Bots"), x + side / 2, by + 8, f(Theme.TEXT));
    hit(K_BOTS, x + 8, by, side - 16, 24, null, null, null);
    small(c, "Right Shift - close", x + 14, y + h - 22, f(Theme.DIM));

    // search
    int sx = x + side + 12, sw = w - side - 24;
    Draw.rrect(c, sx, y + 10, sw, 22, 6, f(Theme.FIELD), f(Theme.BORDER));
    boolean blink = (System.currentTimeMillis() / 500) % 2 == 0;
    c.drawText(textRenderer, Fnt.t(query.isEmpty() ? "Search modules..." : query + (blink ? "_" : "")), sx + 8, y + 17, f(query.isEmpty() ? Theme.DIM : Theme.TEXT), false);

    // content
    vx = sx; vy = y + 40; vw = sw; vh = h - 48;
    int gap = 8, cols = Math.max(1, (vw + gap) / (196 + gap)), cw = (vw - (cols - 1) * gap) / cols;
    int[] colY = new int[cols]; Arrays.fill(colY, 0);
    c.enableScissor(vx, vy, vx + vw, vy + vh);
    String q = query.toLowerCase(Locale.ROOT);
    for (Module m : Zenix.MODULES) {
      if (sel != null && m.cat != sel) continue;
      if (!q.isEmpty() && !m.name.toLowerCase(Locale.ROOT).contains(q)) continue;
      int col = 0; for (int i = 1; i < cols; i++) if (colY[i] < colY[col]) col = i;
      float e = expand.merge(m, 0f, (a, b) -> a);
      e = Draw.approach(e, open == m ? 1f : 0f, dt, 14f * sp); if (Math.abs(e - (open == m ? 1f : 0f)) < 0.01f) e = open == m ? 1f : 0f; expand.put(m, e);
      int extra = extraHeight(m), ch = 38 + Math.round(e * extra);
      int cx = vx + col * (cw + gap), cyy = vy + colY[col] - Math.round(scroll);
      if (cyy + ch >= vy && cyy <= vy + vh) card(c, mx, my, dt, sp, m, cx, cyy, cw, ch, e);
      colY[col] += ch + gap;
    }
    int bottom = 0; for (int v : colY) bottom = Math.max(bottom, v);
    contentH = bottom;
    scrollTarget = Math.max(0, Math.min(scrollTarget, Math.max(0, contentH - vh)));
    c.disableScissor();
    if (contentH > vh) { // slim scrollbar
      int bh = Math.max(20, vh * vh / (int) contentH), bp = (int) ((vh - bh) * (scroll / Math.max(1f, contentH - vh)));
      Draw.rrect(c, vx + vw - 3, vy + bp, 3, bh, 1, f(Theme.OFF));
    }
  }

  int categoryRow(DrawContext c, int mx, int my, int x, int y, int w, Category cat, String title) {
    boolean on = sel == cat, hov = Draw.in(mx, my, x, y, w, 22);
    if (on) { Draw.rrect(c, x, y, w, 22, 6, f(Colors.alpha(Theme.accentDark(), 0.55f))); Draw.rrect(c, x, y + 4, 3, 14, 1, f(Theme.accent())); }
    else if (hov) Draw.rrect(c, x, y, w, 22, 6, f(Theme.CARD));
    c.drawText(textRenderer, Fnt.t(title), x + 12, y + 7, f(on ? Theme.TEXT : Theme.MUTED), false);
    int n = 0; for (Module m : Zenix.MODULES) if ((cat == null || m.cat == cat) && !m.planned) n++;
    String s = String.valueOf(n); c.drawText(textRenderer, Fnt.t(s), x + w - 8 - Fnt.w(textRenderer, s), y + 7, f(Theme.DIM), false);
    hit(K_CAT, x, y, w, 22, null, null, cat);
    return y + 24;
  }

  void card(DrawContext c, int mx, int my, float dt, float sp, Module m, int x, int y, int w, int h, float e) {
    boolean inView = my >= vy && my < vy + vh;
    boolean hov = inView && Draw.in(mx, my, x, y, w, 38);
    float t = tog.getOrDefault(m, m.enabled ? 1f : 0f); t = Draw.approach(t, m.enabled ? 1f : 0f, dt, 16f * sp); tog.put(m, t);
    int border = m.planned ? Theme.BORDER : Colors.lerp(Theme.BORDER, Theme.accentDark(), t);
    Draw.rrect(c, x, y, w, h, 6, f(hov ? Theme.CARD_HOVER : Theme.CARD), f(border));
    c.enableScissor(x, y, x + w, y + h);
    c.drawText(textRenderer, Fnt.t(m.name), x + 10, y + 8, f(m.planned ? Theme.DIM : Theme.TEXT), false);
    small(c, Draw.fit(textRenderer, m.description.isEmpty() ? m.cat.title() : m.description, (int) ((w - 62) / 0.75f)), x + 10, y + 23, f(Theme.DIM));
    if (m.planned) {
      Draw.rrect(c, x + w - 48, y + 12, 38, 14, 7, f(Theme.FIELD));
      small(c, "SOON", x + w - 41, y + 16, f(Theme.DIM));
    } else if (m == Zenix.clickgui) {
      small(c, "GUI", x + w - 28, y + 16, f(Theme.MUTED));
    } else Draw.toggle(c, x + w - 36, y + 12, t, false);
    if (!m.planned) { Hit hh = hit(K_CARD, x, y, w, 38, m, null, null); }

    if (e > 0.02f && !m.planned) {
      int ry = y + 38 + 4;
      c.fill(x + 8, y + 38, x + w - 8, y + 39, f(Theme.BORDER));
      for (Setting s : m.settings) {
        boolean slider = !(s.bool || s.isMode()); int rh = slider ? 30 : 22;
        boolean hr = Draw.in(mx, my, x, ry, w, rh) && inView;
        if (hr) Draw.rrect(c, x + 4, ry, w - 8, rh - 2, 4, f(Theme.ROW));
        c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, s.name, w - 80)), x + 10, ry + (slider ? 4 : 7), f(Theme.MUTED), false);
        if (s.bool) {
          float a = sanim.getOrDefault(s, s.on() ? 1f : 0f); a = Draw.approach(a, s.on() ? 1f : 0f, dt, 18f * sp); sanim.put(s, a);
          Draw.toggle(c, x + w - 36, ry + 4, a, false); if (e > 0.6f) hit(K_BOOL, x, ry, w, rh, m, s, null);
        } else if (s.isMode()) {
          String v = s.mode(); int pwid = Fnt.w(textRenderer, v) + 12;
          Draw.rrect(c, x + w - 10 - pwid, ry + 3, pwid, 15, 7, f(Theme.FIELD), f(Theme.BORDER));
          c.drawText(textRenderer, Fnt.t(v), x + w - 4 - pwid, ry + 7, f(Theme.accentLight()), false);
          if (e > 0.6f) hit(K_MODE, x, ry, w, rh, m, s, null);
        } else {
          String v = s.display(); c.drawText(textRenderer, Fnt.t(v), x + w - 10 - Fnt.w(textRenderer, v), ry + 4, f(Theme.accentLight()), false);
          float frac = (float) ((s.value - s.min) / Math.max(1e-9, s.max - s.min));
          Draw.slider(c, x + 12, ry + 19, w - 24, frac);
          if (e > 0.6f) hit(K_SLIDER, x + 6, ry, w - 12, rh, m, s, null);
        }
        ry += rh;
      }
      boolean hr = Draw.in(mx, my, x, ry, w, 22) && inView; if (hr) Draw.rrect(c, x + 4, ry, w - 8, 20, 4, f(Theme.ROW));
      String kn = binding == m ? "press a key..." : m.key < 0 ? "None" : InputUtil.fromKeyCode(m.key, 0).getLocalizedText().getString();
      c.drawText(textRenderer, Fnt.t("Keybind"), x + 10, ry + 7, f(Theme.MUTED), false);
      int bw = Fnt.w(textRenderer, kn) + 12;
      Draw.rrect(c, x + w - 10 - bw, ry + 3, bw, 15, 7, f(Theme.FIELD), f(binding == m ? Theme.accent() : Theme.BORDER));
      c.drawText(textRenderer, Fnt.t(kn), x + w - 4 - bw, ry + 7, f(Theme.accentLight()), false);
      if (e > 0.6f) hit(K_BIND, x, ry, w, 22, m, null, null);
    }
    c.disableScissor();
  }

  void slide(Hit h, double mx) {
    double f = Math.max(0, Math.min(1, (mx - (h.x + 6)) / (h.w - 12)));
    h.s.set(h.s.min + f * (h.s.max - h.s.min));
  }

  @Override public boolean mouseClicked(double mx, double my, int b) {
    binding = null;
    for (int i = hits.size() - 1; i >= 0; i--) {
      Hit h = hits.get(i);
      if (!Draw.in(mx, my, h.x, h.y, h.w, h.h)) continue;
      if (h.kind != K_CAT && h.kind != K_BOTS && (my < vy || my >= vy + vh)) continue;
      if (b == 0) Zenix.playMenuClick();
      switch (h.kind) {
        case K_CAT -> { sel = h.c; scrollTarget = 0; }
        case K_BOTS -> client.setScreen(new BotsScreen(this));
        case K_CARD -> {
          boolean onSwitch = mx >= h.x + h.w - 42 && h.m != Zenix.clickgui;
          if (b == 0 && onSwitch) h.m.toggle(); else open = open == h.m ? null : h.m;
        }
        case K_BOOL -> h.s.set(h.s.on() ? 0 : 1);
        case K_MODE -> h.s.cycle(b == 1 ? -1 : 1);
        case K_SLIDER -> { drag = h.s; dragHit = h; slide(h, mx); }
        case K_BIND -> binding = h.m;
      }
      return true;
    }
    return super.mouseClicked(mx, my, b);
  }
  @Override public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
    if (drag != null) { slide(dragHit, mx); return true; } return false;
  }
  @Override public boolean mouseReleased(double mx, double my, int b) { if (drag != null) Zenix.save(); drag = null; return false; }
  @Override public boolean mouseScrolled(double mx, double my, double h, double v) {
    scrollTarget = Math.max(0, Math.min(scrollTarget - (float) v * 30f, Math.max(0, contentH - vh))); return true;
  }
  @Override public boolean charTyped(char ch, int mod) {
    if (binding == null && ch >= 32 && ch != 127) { query += ch; scrollTarget = 0; return true; } return false;
  }
  @Override public boolean keyPressed(int key, int sc, int mod) {
    if (binding != null) { binding.key = (key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) ? -1 : key; binding = null; Zenix.save(); return true; }
    if (key == GLFW.GLFW_KEY_BACKSPACE && !query.isEmpty()) { query = query.substring(0, query.length() - 1); return true; }
    if (key == GLFW.GLFW_KEY_V && (mod & GLFW.GLFW_MOD_CONTROL) != 0) { query += client.keyboard.getClipboard().replaceAll("[\\r\\n]", ""); return true; }
    if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && Zenix.clickgui.key == key) { close(); return true; }
    return super.keyPressed(key, sc, mod);
  }
  @Override public void close() { Zenix.save(); super.close(); }
}
