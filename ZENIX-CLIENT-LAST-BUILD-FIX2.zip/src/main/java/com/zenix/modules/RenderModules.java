package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.ui.Draw;
import com.zenix.ui.Theme;
import com.zenix.util.*;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.*;
import net.minecraft.world.chunk.WorldChunk;
import java.util.*;

public final class RenderModules {
  private RenderModules() {}
  static final Category C = Category.RENDER;

  public static void register(List<Module> l) {
    l.add(new Ambience()); l.add(new Arrows()); l.add(new BlockESP()); l.add(new TargetESP());
    l.add(new Tracers()); l.add(new Waypoint()); RenderExtras.register(l); l.add(new WorldTime());
    String shader = "Needs custom render layers/shaders; not verified for 1.21.4 and costly on Android";
    String hook = "Needs a render mixin whose 1.21.4 signatures are not verified yet";
    for (String n : new String[]{"Chams", "ChromaticDistortion", "ShaderHands", "Shaders", "SkyShader"}) l.add(Module.planned(n, C, shader));
    for (String n : new String[]{"AspectRatio", "BetterChat", "BetterF5", "SwingAnimation", "ViewModel", "VisualSpin", "Cape", "Cosmetics"}) l.add(Module.planned(n, C, hook));
    for (String n : new String[]{"AuctionHelper", "BlockOverlay", "Constellation", "SwordTrail", "Taksa", "TripEsp"}) l.add(Module.planned(n, C, "Not implemented yet"));
  }

  static double[] lerpPos(LivingEntity e, float pt) { Vec3d p = e.getLerpedPos(pt); return new double[]{p.x, p.y, p.z}; }
  static Box boxAt(net.minecraft.entity.Entity e, float pt) {
    Vec3d p = e.getLerpedPos(pt);
    return e.getBoundingBox().offset(p.x - e.getX(), p.y - e.getY(), p.z - e.getZ());
  }

  // ------------------------------------------------------------------------------------------------ Arrows
  public static class Arrows extends Module {
    public Arrows() {
      super("Arrows", C, "Screen-edge arrows pointing to nearby players");
      add(new Setting("Size", 6, 3, 16)).add(new Setting("Radius", 40, 20, 120)).add(new Setting("Range", 64, 8, 256));
      add(new Setting("Red", 139, 0, 255)).add(new Setting("Green", 92, 0, 255)).add(new Setting("Blue", 246, 0, 255)).add(new Setting("Alpha", 220, 20, 255));
    }
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance();
      int size = get("Size").i(), rad = get("Radius").i(); double range = get("Range").value;
      int col = (get("Alpha").i() << 24) | (get("Red").i() << 16) | (get("Green").i() << 8) | get("Blue").i();
      Vec3d me = mc.player.getPos(); int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
      for (PlayerEntity p : mc.world.getPlayers()) {
        if (p == mc.player || CombatModules.AntiBot.isBot(p)) continue;
        double dx = p.getX() - me.x, dz = p.getZ() - me.z;
        if (dx * dx + dz * dz > range * range) continue;
        float rel = MathHelper.wrapDegrees((float) Math.toDegrees(Math.atan2(dz, dx)) - 90f - mc.player.getYaw());
        double r = Math.toRadians(rel);
        ctx.getMatrices().push();
        ctx.getMatrices().translate(cx + Math.sin(r) * rad, cy - Math.cos(r) * rad, 0);
        ctx.getMatrices().multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rel));
        for (int i = 0; i < size; i++) ctx.fill(-i / 2, i - size / 2, i / 2 + 1, i - size / 2 + 1, col);
        ctx.getMatrices().pop();
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ TargetESP
  public static class TargetESP extends Module {
    public TargetESP() { super("TargetESP", C, "Box and health around the Aura target (needs Aura on)"); add(new Setting("Show Health", true)); }
    @Override public void onHud(DrawContext ctx, float pt) {
      LivingEntity t = CombatModules.Aura.target; if (t == null || !t.isAlive()) return;
      int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
      double[] b = Project.box(boxAt(t, pt), sw, sh); if (b == null) return;
      Draw.outline(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], Theme.accent());
      if (get("Show Health").on()) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String s = t.getName().getString() + "  " + String.format(Locale.ROOT, "%.1f", t.getHealth() / 2f) + " hp";
        ctx.drawCenteredTextWithShadow(mc.textRenderer, s, (int) ((b[0] + b[2]) / 2), (int) b[1] - 11, Theme.accentLight());
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ Tracers
  public static class Tracers extends Module {
    public Tracers() { super("Tracers", C, "Lines from the screen bottom to nearby players"); add(new Setting("Range", 64, 8, 256)).add(new Setting("Max Lines", 12, 1, 30)); }
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance(); int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(), n = 0;
      for (PlayerEntity p : mc.world.getPlayers()) {
        if (p == mc.player || CombatModules.AntiBot.isBot(p) || mc.player.distanceTo(p) > get("Range").value) continue;
        if (n >= get("Max Lines").i()) break;
        Vec3d pos = p.getLerpedPos(pt); double[] s = Project.point(new Vec3d(pos.x, pos.y + p.getHeight() / 2, pos.z), sw, sh);
        if (s == null) continue;
        n++; Draw.line(ctx, sw / 2.0, sh, s[0], s[1], Friends.is(p.getName().getString()) ? Theme.GOOD : Theme.accentLight());
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ Waypoint
  public static class Waypoint extends Module {
    public Waypoint() { super("Waypoint", C, "Markers for saved points (.waypoint add <name>)"); add(new Setting("Max Distance", 2000, 100, 10000, 100)).add(new Setting("Show Distance", true)); }
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance(); int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(); String dim = Waypoints.dim();
      for (Waypoints.Point w : Waypoints.LIST) {
        if (!w.dim.equals(dim)) continue;
        Vec3d c = new Vec3d(w.x + 0.5, w.y + 1.0, w.z + 0.5); double d = mc.player.getPos().distanceTo(c);
        if (d > get("Max Distance").value) continue;
        double[] s = Project.point(c, sw, sh); if (s == null || s[0] < 0 || s[0] > sw || s[1] < 0 || s[1] > sh) continue;
        int x = (int) s[0], y = (int) s[1];
        ctx.fill(x - 2, y - 2, x + 3, y + 3, Theme.accent());
        ctx.drawCenteredTextWithShadow(mc.textRenderer, get("Show Distance").on() ? w.name + " " + (int) d + "m" : w.name, x, y + 6, 0xFFEDE7FF);
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ WorldTime
  public static class WorldTime extends Module {
    long t;
    public WorldTime() { super("WorldTime", C, "Client-side fixed time or fast day/night cycle"); add(new Setting("Mode", "Cycle", "Day", "Noon", "Sunset", "Night", "Midnight", "Cycle")).add(new Setting("Cycle Speed", 20, 1, 100)); }
    @Override public void onEnable() { MinecraftClient mc = MinecraftClient.getInstance(); t = mc.world == null ? 0 : mc.world.getTimeOfDay(); }
    @Override public void onTick(MinecraftClient mc) {
      Setting m = get("Mode");
      if (m.is("Cycle")) t += get("Cycle Speed").i();
      else t = m.is("Day") ? 1000 : m.is("Noon") ? 6000 : m.is("Sunset") ? 12500 : m.is("Night") ? 14000 : 18000;
      mc.world.getLevelProperties().setTimeOfDay(t);
    }
  }

  // ------------------------------------------------------------------------------------------------ BlockESP
  public static class BlockESP extends Module {
    static final class Cell { long scanned; final List<Long> pos = new ArrayList<>(); }
    final Map<Long, Cell> cells = new HashMap<>(); int rr; Object lastWorld;
    public BlockESP() {
      super("BlockESP", C, "Boxes around chosen blocks in loaded chunks (not through anti-xray)");
      add(new Setting("Target", "Storage", "Storage", "Spawner", "Diamond", "Ancient Debris", "Emerald"));
      add(new Setting("Radius (chunks)", 3, 1, 8)).add(new Setting("Range", 64, 8, 160, 8)).add(new Setting("Max Boxes", 60, 10, 200, 10)).add(new Setting("Scan Speed", 1, 1, 4));
    }
    boolean match(BlockState s) {
      Block b = s.getBlock();
      return switch (get("Target").mode()) {
        case "Storage" -> b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL || b == Blocks.ENDER_CHEST || b instanceof ShulkerBoxBlock;
        case "Spawner" -> b == Blocks.SPAWNER;
        case "Diamond" -> b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE;
        case "Ancient Debris" -> b == Blocks.ANCIENT_DEBRIS;
        default -> b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE;
      };
    }
    @Override public void onEnable() { cells.clear(); }
    @Override public void onTick(MinecraftClient mc) {
      if (mc.world != lastWorld) { lastWorld = mc.world; cells.clear(); }
      int r = Math.min(get("Radius (chunks)").i(), mc.options.getViewDistance().getValue()), pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4, budget = get("Scan Speed").i();
      long now = System.currentTimeMillis(); String tgt = get("Target").mode();
      if (!tgt.equals(lastTarget)) { lastTarget = tgt; cells.clear(); }
      for (int ring = 0; ring <= r && budget > 0; ring++) for (int dx = -ring; dx <= ring && budget > 0; dx++) for (int dz = -ring; dz <= ring && budget > 0; dz++) {
        if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) continue;
        long key = ((long) (pcx + dx) << 32) | ((pcz + dz) & 0xFFFFFFFFL); Cell old = cells.get(key);
        if (old != null && now - old.scanned < 10000) continue;
        WorldChunk ch = mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz); if (ch == null) continue;
        Cell c = new Cell(); c.scanned = now;
        ChunkScan.scan(ch, mc.world.getBottomY(), mc.world.getBottomY() + mc.world.getHeight() - 1, this::match, (p, s) -> { if (c.pos.size() < 256) c.pos.add(p.asLong()); });
        cells.put(key, c); budget--;
      }
    }
    String lastTarget = "";
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance(); int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(), n = 0, max = get("Max Boxes").i();
      Vec3d me = mc.player.getPos(); double rng = get("Range").value;
      for (Cell c : cells.values()) for (long l : c.pos) {
        if (n >= max) return;
        BlockPos p = BlockPos.fromLong(l);
        if (me.squaredDistanceTo(p.getX() + 0.5, p.getY() + 0.5, p.getZ() + 0.5) > rng * rng) continue;
        double[] b = Project.box(new Box(p), sw, sh); if (b == null) continue;
        n++; Draw.outline(ctx, (int) b[0], (int) b[1], (int) b[2] + 1, (int) b[3] + 1, Theme.accentLight());
      }
    }
  }
}
