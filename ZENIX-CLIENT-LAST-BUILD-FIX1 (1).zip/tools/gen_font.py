#!/usr/bin/env python3
"""Generates the ZENIX bitmap font atlas (Latin + Cyrillic) from a TTF. Usage: gen_font.py <ttf> <outdir>
Bitmap fonts are used instead of the TTF provider because the TTF provider needs FreeType natives that
Android launchers may not ship. Montserrat is licensed under the SIL OFL 1.1."""
import sys, json
from PIL import Image, ImageDraw, ImageFont
ttf, out = sys.argv[1], sys.argv[2]
CELL, COLS, SIZE, BASE = 32, 16, 26, 26
chars = [chr(c) for c in range(32, 127)] + [chr(c) for c in range(0x410, 0x450)] + ['\u0401', '\u0451'] + list('\u00b7\u2014\u00ab\u00bb\u2116\u00b0\u2022\u00d7')
while len(chars) % COLS: chars.append('\u0000')
rows = len(chars) // COLS
img = Image.new('RGBA', (COLS * CELL, rows * CELL), (0, 0, 0, 0))
font = ImageFont.truetype(ttf, SIZE)
notdef = font.getmask('\uffff')
for i, ch in enumerate(chars):
    if ch in ('\u0000', ' '): continue
    x, y = (i % COLS) * CELL, (i // COLS) * CELL
    m = Image.new('L', (CELL, CELL), 0)
    ImageDraw.Draw(m).text((3, BASE), ch, font=font, fill=255, anchor='ls')
    img.paste(Image.new('RGBA', (CELL, CELL), (255, 255, 255, 255)), (x, y), m)
img.save(f'{out}/textures/font/ui.png', optimize=True)
json.dump({"providers": [{"type": "bitmap", "file": "zenix:font/ui.png", "ascent": 8, "height": 10,
    "chars": [''.join(chars[r * COLS:(r + 1) * COLS]) for r in range(rows)]}]},
    open(f'{out}/font/ui.json', 'w'), ensure_ascii=False, indent=1)
print('glyphs', len([c for c in chars if c != '\u0000']), 'atlas', img.size)
