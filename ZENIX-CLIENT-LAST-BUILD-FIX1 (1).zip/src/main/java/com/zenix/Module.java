package com.zenix;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import java.util.*;

/**
 * Base class of every ZENIX module. A module is either implemented (overrides hooks) or "planned":
 * planned modules are listed in the ClickGUI but can never be enabled and do nothing.
 */
public class Module {
  public enum Category {
    COMBAT, MOVEMENT, PLAYER, RENDER, MISC;
    public String title() { return name().charAt(0) + name().substring(1).toLowerCase(Locale.ROOT); }
  }

  public final String name;
  public final Category cat;
  public String description = "";
  public boolean enabled;
  public int key = -1;
  /** true = not implemented yet; shown dimmed in the GUI, cannot be enabled. */
  public boolean planned;
  /** one-shot modules perform an action on enable and switch themselves off; never restored enabled from config. */
  public boolean oneShot;
  public final List<Setting> settings = new ArrayList<>();

  public Module(String n, Category c) { name = n; cat = c; }
  public Module(String n, Category c, String desc) { this(n, c); description = desc; }

  public static Module planned(String n, Category c, String reason) {
    Module m = new Module(n, c, reason);
    m.planned = true;
    return m;
  }

  public Module add(Setting s) { settings.add(s); return this; }
  public Setting get(String n) {
    for (Setting s : settings) if (s.name.equals(n)) return s;
    throw new IllegalArgumentException(name + ": no setting " + n);
  }

  public void toggle() { setEnabled(!enabled); }
  public void setEnabled(boolean v) {
    if (planned || v == enabled) return;
    enabled = v;
    try { if (v) onEnable(); else onDisable(); }
    catch (Throwable t) { Zenix.LOG.error("ZENIX: module {} failed in enable/disable", name, t); }
  }

  /** Called when the module's keybind is pressed (outside of screens). */
  public void onKey(MinecraftClient mc) { toggle(); }

  public void onEnable() {}
  public void onDisable() {}
  /** Every client tick while enabled and a world is loaded. */
  public void onTick(MinecraftClient mc) {}
  /** HUD pass while enabled, a world is loaded and no screen is open. */
  public void onHud(DrawContext ctx, float tickDelta) {}
  /** Incoming game/system chat line (plain text). */
  public void onChat(String message) {}
}
