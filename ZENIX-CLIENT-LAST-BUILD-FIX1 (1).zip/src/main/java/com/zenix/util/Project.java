package com.zenix.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * World-to-screen projection done on the CPU, so 2D overlays (ESP boxes, tracers, markers) need no render-layer hooks.
 * Uses the camera position/rotation and the FOV option; ignores dynamic FOV effects (sprint/speed), so it is approximate.
 */
public final class Project {
  private Project() {}

  /** @return {x, y} in scaled GUI coordinates, or null if the point is behind the camera. */
  public static double[] point(Vec3d p, int sw, int sh) {
    MinecraftClient mc = MinecraftClient.getInstance();
    Camera cam = mc.gameRenderer.getCamera();
    Vec3d c = cam.getPos();
    double yaw = Math.toRadians(cam.getYaw()), pitch = Math.toRadians(cam.getPitch());
    double fx = -Math.sin(yaw) * Math.cos(pitch), fy = -Math.sin(pitch), fz = Math.cos(yaw) * Math.cos(pitch);
    double rx = -Math.cos(yaw), ry = 0, rz = -Math.sin(yaw);
    double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
    double dx = p.x - c.x, dy = p.y - c.y, dz = p.z - c.z;
    double zc = dx * fx + dy * fy + dz * fz;
    if (zc < 0.05) return null;
    double xc = dx * rx + dy * ry + dz * rz, yc = dx * ux + dy * uy + dz * uz;
    double t = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
    return new double[]{sw / 2.0 + (xc / zc) / t * (sh / 2.0), sh / 2.0 - (yc / zc) / t * (sh / 2.0)};
  }

  /** Screen-space bounding rectangle {x1,y1,x2,y2} of a world box, or null if any corner is behind the camera. */
  public static double[] box(Box b, int sw, int sh) {
    double x1 = Double.MAX_VALUE, y1 = Double.MAX_VALUE, x2 = -Double.MAX_VALUE, y2 = -Double.MAX_VALUE;
    for (int i = 0; i < 8; i++) {
      double[] s = point(new Vec3d((i & 1) == 0 ? b.minX : b.maxX, (i & 2) == 0 ? b.minY : b.maxY, (i & 4) == 0 ? b.minZ : b.maxZ), sw, sh);
      if (s == null) return null;
      x1 = Math.min(x1, s[0]); y1 = Math.min(y1, s[1]); x2 = Math.max(x2, s[0]); y2 = Math.max(y2, s[1]);
    }
    return new double[]{x1, y1, x2, y2};
  }
}
