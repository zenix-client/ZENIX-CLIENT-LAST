package com.zenix.util;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import java.nio.file.*;
import java.util.*;

public final class Waypoints {
  private Waypoints() {}
  public static final class Point {
    public String name, dim; public int x, y, z;
    public Point(String n, String d, int x, int y, int z) { name = n; dim = d; this.x = x; this.y = y; this.z = z; }
  }
  public static final List<Point> LIST = new ArrayList<>();
  private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zenix-waypoints.json");

  public static String dim() {
    MinecraftClient mc = MinecraftClient.getInstance();
    return mc.world == null ? "" : mc.world.getRegistryKey().getValue().toString();
  }
  public static void add(String name) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.player == null) return;
    LIST.removeIf(p -> p.name.equalsIgnoreCase(name) && p.dim.equals(dim()));
    LIST.add(new Point(name, dim(), mc.player.getBlockX(), mc.player.getBlockY(), mc.player.getBlockZ()));
    save();
  }
  public static boolean remove(String name) { boolean r = LIST.removeIf(p -> p.name.equalsIgnoreCase(name) && p.dim.equals(dim())); save(); return r; }

  public static void load() {
    try {
      if (!Files.exists(FILE)) return;
      for (JsonElement e : JsonParser.parseString(Files.readString(FILE)).getAsJsonArray()) {
        JsonObject o = e.getAsJsonObject();
        LIST.add(new Point(o.get("name").getAsString(), o.get("dim").getAsString(), o.get("x").getAsInt(), o.get("y").getAsInt(), o.get("z").getAsInt()));
      }
    } catch (Exception e) { e.printStackTrace(); }
  }
  static void save() {
    try {
      JsonArray a = new JsonArray();
      for (Point p : LIST) { JsonObject o = new JsonObject(); o.addProperty("name", p.name); o.addProperty("dim", p.dim); o.addProperty("x", p.x); o.addProperty("y", p.y); o.addProperty("z", p.z); a.add(o); }
      Files.writeString(FILE, a.toString());
    } catch (Exception e) { e.printStackTrace(); }
  }
}
