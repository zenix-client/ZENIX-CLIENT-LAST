package com.zenix.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import java.util.function.Predicate;

public final class Inv {
  private Inv() {}
  /** hotbar index 0..8 or -1 */
  public static int hotbar(Predicate<ItemStack> p) {
    var inv = MinecraftClient.getInstance().player.getInventory();
    for (int i = 0; i < 9; i++) if (p.test(inv.getStack(i))) return i;
    return -1;
  }
  /** inventory index 0..35 (0-8 hotbar, 9-35 main) or -1 */
  public static int any(Predicate<ItemStack> p) {
    var inv = MinecraftClient.getInstance().player.getInventory();
    for (int i = 0; i < 36; i++) if (p.test(inv.getStack(i))) return i;
    return -1;
  }
  /** slot id in PlayerScreenHandler for an inventory index */
  public static int screenSlot(int invIndex) { return invIndex < 9 ? 36 + invIndex : invIndex; }
  public static String id(ItemStack s) { return Registries.ITEM.getId(s.getItem()).getPath(); }
}
