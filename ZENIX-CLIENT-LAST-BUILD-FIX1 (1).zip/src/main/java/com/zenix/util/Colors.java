package com.zenix.util;

/** Colour helpers without java.awt (not available on Android JREs). */
public final class Colors {
  private Colors() {}

  public static int hsv(float h, float s, float v) {
    h = (h - (float) Math.floor(h)) * 6f;
    int i = (int) h; float f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
    float r, g, b;
    switch (i) { case 0 -> { r = v; g = t; b = p; } case 1 -> { r = q; g = v; b = p; } case 2 -> { r = p; g = v; b = t; }
      case 3 -> { r = p; g = q; b = v; } case 4 -> { r = t; g = p; b = v; } default -> { r = v; g = p; b = q; } }
    return 0xFF000000 | ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
  }
  public static int lerp(int a, int b, float t) {
    t = Math.max(0, Math.min(1, t));
    int aa = (int) (((a >>> 24) & 255) * (1 - t) + ((b >>> 24) & 255) * t), ar = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
    int ag = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t), ab = (int) ((a & 255) * (1 - t) + (b & 255) * t);
    return (aa << 24) | (ar << 16) | (ag << 8) | ab;
  }
  /** multiplies the alpha channel */
  public static int alpha(int c, float m) { int a = (int) (((c >>> 24) & 255) * Math.max(0, Math.min(1, m))); return (a << 24) | (c & 0xFFFFFF); }
  public static int rgb(int r, int g, int b) { return 0xFF000000 | (clamp(r) << 16) | (clamp(g) << 8) | clamp(b); }
  static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
}
