package com.zenix.util;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import java.util.function.Predicate;

/** Scans only the blocks of a loaded client chunk. Uses the section palette first so empty/irrelevant sections cost almost nothing. */
public final class ChunkScan {
  private ChunkScan() {}

  public interface Visitor { void visit(BlockPos pos, BlockState state); }

  public static void scan(WorldChunk chunk, int minY, int maxY, Predicate<BlockState> filter, Visitor v) {
    ChunkSection[] secs = chunk.getSectionArray();
    int bottom = chunk.getBottomY();
    int cx = chunk.getPos().getStartX(), cz = chunk.getPos().getStartZ();
    BlockPos.Mutable mp = new BlockPos.Mutable();
    for (int i = 0; i < secs.length; i++) {
      ChunkSection sec = secs[i];
      if (sec == null || sec.isEmpty()) continue;
      int y0 = bottom + i * 16;
      if (y0 + 15 < minY || y0 > maxY) continue;
      if (!sec.hasAny(filter)) continue;
      for (int y = 0; y < 16; y++) {
        int wy = y0 + y;
        if (wy < minY || wy > maxY) continue;
        for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
          BlockState s = sec.getBlockState(x, y, z);
          if (s.isAir() || !filter.test(s)) continue;
          mp.set(cx + x, wy, cz + z);
          v.visit(mp, s);
        }
      }
    }
  }
}
