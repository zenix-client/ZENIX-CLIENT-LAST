package com.zenix.ui;

import com.zenix.bots.Bot;
import com.zenix.bots.BotManager;
import com.zenix.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import java.util.*;

/**
 * Bots tab. Every bot here is a REAL separate network session (see Bot.java), never a local FakePlayer.
 * Modules / Configs / Settings / Proxy tabs of the reference design are shown but marked "soon" (not implemented).
 */
public class BotsScreen extends Screen {
  static final int F_NONE = 0, F_NAME = 1, F_HOST = 2, F_CHAT = 3;
  static final class Hit { int x, y, w, h; Runnable a; Hit(int x, int y, int w, int h, Runnable a) { this.x = x; this.y = y; this.w = w; this.h = h; this.a = a; } }

  final Screen parent;
  int focus = F_NONE; boolean adding; String newName = "", chatIn = "", status = "";
  final List<Hit> hits = new ArrayList<>();
  float fade; long last;

  public BotsScreen(Screen parent) { super(Text.literal("ZENIX Bots")); this.parent = parent; }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}
  @Override public boolean shouldPause() { return false; }
  @Override public void close() { BotManager.save(); client.setScreen(parent); }

  static int stateColor(Bot.State s) {
    return switch (s) { case ONLINE -> Theme.GOOD; case CONNECTING, LOGIN, CONFIG -> Theme.WARN; case ERROR, DISCONNECTED -> Theme.BAD; default -> Theme.DIM; };
  }
  int f(int col) { return Colors.alpha(col, fade); }
  void btn(DrawContext c, int mx, int my, int x, int y, int w, String t, boolean primary, boolean enabled, Runnable a) {
    boolean h = enabled && Draw.in(mx, my, x, y, w, 22);
    int bg = !enabled ? Theme.FIELD : primary ? (h ? Theme.accent() : Theme.accentDark()) : (h ? Theme.CARD_HOVER : Theme.CARD);
    Draw.rrect(c, x, y, w, 22, 6, f(bg), f(primary && enabled ? Theme.accent() : Theme.BORDER));
    c.drawCenteredTextWithShadow(textRenderer, Fnt.t(t), x + w / 2, y + 7, f(enabled ? Theme.TEXT : Theme.DIM));
    if (enabled) hits.add(new Hit(x, y, w, 22, a));
  }
  void field(DrawContext c, int x, int y, int w, String text, String hint, int id) {
    boolean foc = focus == id, blink = (System.currentTimeMillis() / 500) % 2 == 0;
    Draw.rrect(c, x, y, w, 22, 6, f(Theme.FIELD), f(foc ? Theme.accent() : Theme.BORDER));
    String s = text.isEmpty() && !foc ? hint : text + (foc && blink ? "_" : "");
    c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, s, w - 14)), x + 7, y + 7, f(text.isEmpty() && !foc ? Theme.DIM : Theme.TEXT), false);
    hits.add(new Hit(x, y, w, 22, () -> focus = id));
  }

  @Override public void render(DrawContext c, int mx, int my, float d) {
    long now = System.nanoTime(); float dt = last == 0 ? 0.016f : Math.min(0.1f, (now - last) / 1e9f); last = now;
    fade = Draw.approach(fade, 1f, dt, 14f); hits.clear();
    c.fill(0, 0, width, height, f(0xC005030A));
    int pw = Math.min(width - 12, 780), ph = Math.min(height - 12, 450), x = (width - pw) / 2, y = (height - ph) / 2, lw = 170;
    Draw.rrect(c, x - 1, y - 1, pw + 2, ph + 2, 8, f(Theme.BORDER)); Draw.rrect(c, x, y, pw, ph, 8, f(Theme.BG));
    Draw.rrect(c, x, y, lw, ph, 8, f(Theme.SIDEBAR)); c.fill(x + lw - 8, y, x + lw, y + ph, f(Theme.SIDEBAR));

    // left: bot list
    c.drawText(textRenderer, Fnt.t("Bots"), x + 14, y + 14, f(Theme.TEXT), false);
    c.drawText(textRenderer, Fnt.t(BotManager.BOTS.size() + "/" + BotManager.MAX_BOTS), x + 14, y + 27, f(Theme.DIM), false);
    btn(c, mx, my, x + lw - 38, y + 10, 28, "+", true, BotManager.BOTS.size() < BotManager.MAX_BOTS, () -> { adding = true; focus = F_NAME; newName = "ZenixBot" + (BotManager.BOTS.size() + 1); status = ""; });
    int ly = y + 44;
    if (adding) {
      field(c, x + 8, ly, lw - 16, newName, "bot name", F_NAME); ly += 26;
      btn(c, mx, my, x + 8, ly, (lw - 20) / 2, "Create", true, true, this::create);
      btn(c, mx, my, x + 12 + (lw - 20) / 2, ly, (lw - 20) / 2, "Cancel", false, true, () -> { adding = false; focus = F_NONE; });
      ly += 30;
    }
    for (Bot b : BotManager.BOTS) {
      boolean sel = b.id == BotManager.selected, hv = Draw.in(mx, my, x + 8, ly, lw - 16, 36);
      Draw.rrect(c, x + 8, ly, lw - 16, 36, 6, f(sel ? Colors.alpha(Theme.accentDark(), 0.55f) : hv ? Theme.CARD : Theme.SIDEBAR), f(sel ? Theme.accent() : Theme.BORDER));
      c.fill(x + 16, ly + 14, x + 22, ly + 20, f(stateColor(b.state)));
      c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, b.name, lw - 52)), x + 28, ly + 7, f(Theme.TEXT), false);
      c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, b.host.isEmpty() ? "no server" : b.host, lw - 52)), x + 28, ly + 20, f(Theme.DIM), false);
      final Bot fb = b; hits.add(new Hit(x + 8, ly, lw - 16, 36, () -> { BotManager.selected = fb.id; focus = F_NONE; status = ""; }));
      ly += 40;
    }
    if (BotManager.BOTS.isEmpty() && !adding) c.drawText(textRenderer, Fnt.t("No bots yet"), x + 14, ly + 4, f(Theme.DIM), false);
    btn(c, mx, my, x + 8, y + ph - 32, lw - 16, "Back", false, true, this::close);

    // right: details
    int rx = x + lw + 14, rw = pw - lw - 28; Bot b = BotManager.selected();
    if (b == null) {
      c.drawCenteredTextWithShadow(textRenderer, Fnt.t("Create a bot with  +  to get started"), rx + rw / 2, y + ph / 2 - 10, f(Theme.MUTED));
      c.drawCenteredTextWithShadow(textRenderer, Fnt.t("Bots are real network sessions (offline-mode servers only)"), rx + rw / 2, y + ph / 2 + 4, f(Theme.DIM));
      return;
    }
    c.getMatrices().push(); c.getMatrices().translate(rx, y + 14, 0); c.getMatrices().scale(1.5f, 1.5f, 1f);
    c.drawText(textRenderer, Fnt.t("" + b.name), 0, 0, f(Theme.TEXT), false); c.getMatrices().pop();
    String sn = b.state.name().charAt(0) + b.state.name().substring(1).toLowerCase(Locale.ROOT);
    int sbw = Fnt.w(textRenderer, sn) + 22;
    Draw.rrect(c, rx + rw - sbw, y + 14, sbw, 18, 9, f(Theme.FIELD), f(stateColor(b.state)));
    c.fill(rx + rw - sbw + 8, y + 20, rx + rw - sbw + 13, y + 25, f(stateColor(b.state)));
    c.drawText(textRenderer, Fnt.t(sn), rx + rw - sbw + 17, y + 19, f(Theme.TEXT), false);
    // tabs
    int tx = rx, ty = y + 42; String[] tabs = {"Overview", "Modules", "Configs", "Settings", "Proxy"};
    for (int i = 0; i < tabs.length; i++) {
      int tw = Fnt.w(textRenderer, tabs[i]) + 22; boolean on = i == 0;
      Draw.rrect(c, tx, ty, tw, 20, 6, f(on ? Theme.accentDark() : Theme.SIDEBAR), f(on ? Theme.accent() : Theme.BORDER));
      c.drawText(textRenderer, Fnt.t(tabs[i]), tx + 11, ty + 6, f(on ? Theme.TEXT : Theme.DIM), false);
      if (!on) hits.add(new Hit(tx, ty, tw, 20, () -> status = "This tab is not implemented yet"));
      tx += tw + 6;
    }
    // controls
    int cy = y + 70, bw = (rw - 18) / 4; boolean running = b.running();
    btn(c, mx, my, rx, cy, bw, "Connect", true, !running, () -> { String e = b.connect(); status = e == null ? "" : e; });
    btn(c, mx, my, rx + bw + 6, cy, bw, "Reconnect", false, true, () -> { b.disconnect(); Bot nb = b; nb.lastAttempt = 0; String e = nb.connect(); status = e == null ? "" : e; });
    btn(c, mx, my, rx + 2 * (bw + 6), cy, bw, "Disconnect", false, running, b::disconnect);
    btn(c, mx, my, rx + 3 * (bw + 6), cy, bw, "Delete", false, true, () -> BotManager.remove(b));
    // server
    int sy = cy + 30;
    c.drawText(textRenderer, Fnt.t("Server"), rx, sy, f(Theme.MUTED), false);
    String hostText = b.port == 25565 ? b.host : b.host + ":" + b.port;
    field(c, rx, sy + 11, rw - 120, hostText, "play.example.com[:port]", F_HOST);
    btn(c, mx, my, rx + rw - 114, sy + 11, 114, "Current server", false, client.getCurrentServerEntry() != null, () -> { setHost(b, client.getCurrentServerEntry().address); });
    // info
    int iy = sy + 40;
    String line = b.state == Bot.State.ONLINE ? "Online for " + (System.currentTimeMillis() - b.onlineSince) / 1000 + "s" : b.info.isEmpty() ? "Offline-mode servers only. Captchas / bot filters are not solved." : b.info;
    c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, line, rw)), rx, iy, f(b.state == Bot.State.ERROR || b.state == Bot.State.DISCONNECTED ? Theme.BAD : Theme.MUTED), false);
    if (!status.isEmpty()) c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, status, rw)), rx, iy + 11, f(Theme.WARN), false);
    // chat
    int chy = iy + 26, chh = y + ph - 46 - chy;
    Draw.rrect(c, rx, chy, rw, chh, 6, f(Theme.PANEL), f(Theme.BORDER));
    c.drawText(textRenderer, Fnt.t("Bot chat"), rx + 8, chy + 6, f(Theme.accentLight()), false);
    int lines = Math.max(1, (chh - 22) / 10); List<String> all = new ArrayList<>(b.chat);
    int from = Math.max(0, all.size() - lines);
    for (int i = from; i < all.size(); i++) c.drawText(textRenderer, Fnt.t(Draw.fit(textRenderer, all.get(i), rw - 16)), rx + 8, chy + 20 + (i - from) * 10, f(Theme.TEXT), false);
    field(c, rx, y + ph - 36, rw - 70, chatIn, b.state == Bot.State.ONLINE ? "message or /command, Enter to send" : "connect first to chat", F_CHAT);
    btn(c, mx, my, rx + rw - 64, y + ph - 36, 64, "Send", true, b.state == Bot.State.ONLINE, () -> sendChat(b));
  }

  void create() {
    String e = BotManager.add(newName.trim());
    if (e == null) { adding = false; focus = F_NONE; status = ""; } else status = e;
  }
  void setHost(Bot b, String text) {
    text = text.trim(); int i = text.lastIndexOf(':');
    if (i > 0 && i < text.length() - 1 && text.indexOf(':') == i) { try { b.port = Integer.parseInt(text.substring(i + 1)); b.host = text.substring(0, i); } catch (NumberFormatException e) { b.host = text; } }
    else { b.host = text; b.port = 25565; }
    BotManager.save();
  }
  void sendChat(Bot b) { if (b.sendChat(chatIn)) chatIn = ""; else status = "message not sent"; }

  @Override public boolean mouseClicked(double mx, double my, int btn) {
    focus = F_NONE;
    for (int i = hits.size() - 1; i >= 0; i--) { Hit h = hits.get(i); if (Draw.in(mx, my, h.x, h.y, h.w, h.h)) { h.a.run(); return true; } }
    return super.mouseClicked(mx, my, btn);
  }
  String buf() {
    Bot b = BotManager.selected();
    return switch (focus) { case F_NAME -> newName; case F_CHAT -> chatIn; case F_HOST -> b == null ? "" : (b.port == 25565 ? b.host : b.host + ":" + b.port); default -> null; };
  }
  void edit(String s) {
    Bot b = BotManager.selected();
    switch (focus) { case F_NAME -> newName = s; case F_CHAT -> chatIn = s; case F_HOST -> { if (b != null) setHost(b, s); } default -> {} }
  }
  @Override public boolean charTyped(char ch, int mod) {
    String s = buf(); if (s == null || ch < 32 || ch == 127 || s.length() > 120) return false;
    edit(s + ch); return true;
  }
  Bot b() { return BotManager.selected(); }
  @Override public boolean keyPressed(int key, int sc, int mod) {
    String s = buf();
    if (s != null) {
      if (key == GLFW.GLFW_KEY_BACKSPACE) { if (!s.isEmpty()) edit(s.substring(0, s.length() - 1)); return true; }
      if (key == GLFW.GLFW_KEY_V && (mod & GLFW.GLFW_MOD_CONTROL) != 0) { edit(s + client.keyboard.getClipboard().replaceAll("[\\r\\n]", "")); return true; }
      if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
        if (focus == F_NAME) create(); else if (focus == F_CHAT && b() != null) sendChat(b()); else focus = F_NONE;
        return true;
      }
      if (key == GLFW.GLFW_KEY_ESCAPE) { focus = F_NONE; adding = false; return true; }
    }
    return super.keyPressed(key, sc, mod);
  }
}
