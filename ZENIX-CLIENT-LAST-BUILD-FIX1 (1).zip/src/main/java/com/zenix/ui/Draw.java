package com.zenix.ui;

import com.zenix.util.Colors;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Small immediate-mode drawing helpers built only on DrawContext.fill (no custom shaders, cheap on Android GPUs). */
public final class Draw {
  private Draw() {}

  public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
    if (w <= 0 || h <= 0) return;
    r = Math.min(r, Math.min(w, h) / 2);
    if (r <= 0) { c.fill(x, y, x + w, y + h, col); return; }
    c.fill(x, y + r, x + w, y + h - r, col);
    for (int i = 0; i < r; i++) {
      double dy = r - i - 0.5; int inset = (int) Math.round(r - Math.sqrt(r * r - dy * dy));
      c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
      c.fill(x + inset, y + h - 1 - i, x + w - inset, y + h - i, col);
    }
  }
  public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
    rrect(c, x, y, w, h, r, border); rrect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
  }
  public static void outline(DrawContext c, int x1, int y1, int x2, int y2, int col) {
    c.fill(x1, y1, x2, y1 + 1, col); c.fill(x1, y2 - 1, x2, y2, col); c.fill(x1, y1, x1 + 1, y2, col); c.fill(x2 - 1, y1, x2, y2, col);
  }
  public static void line(DrawContext c, double x1, double y1, double x2, double y2, int col) {
    double dx = x2 - x1, dy = y2 - y1; int n = (int) Math.min(2000, Math.max(Math.abs(dx), Math.abs(dy)));
    if (n <= 0) return;
    for (int i = 0; i <= n; i++) { int x = (int) (x1 + dx * i / n), y = (int) (y1 + dy * i / n); c.fill(x, y, x + 1, y + 1, col); }
  }
  /** rounded switch, anim 0..1 */
  public static void toggle(DrawContext c, int x, int y, float anim, boolean dim) {
    int track = Colors.lerp(Theme.OFF, Theme.accent(), anim);
    rrect(c, x, y, 26, 14, 7, dim ? Colors.alpha(track, 0.45f) : track);
    int kx = x + 2 + Math.round(anim * 12);
    rrect(c, kx, y + 2, 10, 10, 5, 0xFFF4F0FF);
  }
  public static void slider(DrawContext c, int x, int y, int w, float frac) {
    rrect(c, x, y, w, 4, 2, Theme.OFF);
    int fw = Math.max(0, Math.round(w * Math.max(0, Math.min(1, frac))));
    if (fw > 0) rrect(c, x, y, Math.max(fw, 4), 4, 2, Theme.accent());
    rrect(c, x + fw - 3, y - 2, 7, 8, 3, 0xFFF4F0FF);
  }
  public static String fit(TextRenderer tr, String s, int maxW) {
    if (Fnt.w(tr, s) <= maxW) return s;
    int n = s.length();
    while (n > 0 && Fnt.w(tr, s.substring(0, n) + "...") > maxW) n--;
    return s.substring(0, n) + "...";
  }
  public static boolean in(double mx, double my, int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }
  /** exponential approach, frame-rate independent */
  public static float approach(float cur, float target, float dt, float speed) {
    return cur + (target - cur) * (1f - (float) Math.exp(-dt * speed));
  }
}
