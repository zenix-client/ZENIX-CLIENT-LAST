package com.zenix.ui;

import com.zenix.Zenix;

/** Near-black and neutral-gray palette matching the supplied Britva/Obsidian reference. Accent variants stay grayscale. */
public final class Theme {
  private Theme() {}
  public static final int BG = 0xF2080808, SIDEBAR = 0xFF0C0C0C, PANEL = 0xFF101010, CARD = 0xFF111111, CARD_HOVER = 0xFF191919,
    ROW = 0xFF141414, FIELD = 0xFF171717, BORDER = 0xFF242424, OFF = 0xFF383838, TEXT = 0xFFF0F0F0, MUTED = 0xFFAAAAAA, DIM = 0xFF707070;
  static final int[][] ACCENTS = {{0xFFBDBDBD, 0xFF777777, 0xFFE0E0E0}, {0xFF9E9E9E, 0xFF616161, 0xFFD6D6D6}, {0xFFD0D0D0, 0xFF888888, 0xFFF0F0F0}};
  static int idx() { try { return Zenix.clickgui == null ? 0 : Zenix.clickgui.get("Accent").i(); } catch (Exception e) { return 0; } }
  public static int accent() { return ACCENTS[idx()][0]; }
  public static int accentDark() { return ACCENTS[idx()][1]; }
  public static int accentLight() { return ACCENTS[idx()][2]; }
  public static final int GOOD = 0xFF7DD3A8, BAD = 0xFFE5707E, WARN = 0xFFE9C46A;
}
