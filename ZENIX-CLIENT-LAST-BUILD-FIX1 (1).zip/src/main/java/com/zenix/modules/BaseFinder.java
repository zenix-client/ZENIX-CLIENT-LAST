package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Setting;
import com.zenix.ui.Draw;
import com.zenix.ui.Theme;
import com.zenix.util.*;
import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import java.util.*;

/**
 * Finds player-built structures from the block data the client really has: only chunks the server already sent
 * (inside render distance) can be scanned. Within those chunks the scan sees blocks even when they are behind walls or
 * underground, because chunk data is complete on the client - unless the server hides them (anti-xray, plugins).
 * It never "sees" beyond loaded chunks. Results are a heuristic score, not proof of a player base.
 */
public class BaseFinder extends Module {
  static final String[] CAT = {"Storage", "Workstation", "Bed", "Redstone", "Valuable", "Spawner", "Building"};
  static final int STORAGE = 0, WORK = 1, BED = 2, REDSTONE = 3, VALUABLE = 4, SPAWNER = 5, BUILDING = 6;
  static final String[] FILTER_NAME = {"Storage", "Workstations", "Beds", "Redstone", "Valuables", "Spawners", "Building Blocks"};

  private static final IdentityHashMap<Block, int[]> TABLE = new IdentityHashMap<>(); // block -> {category, weight}
  private static final Set<Block> VILLAGE = Collections.newSetFromMap(new IdentityHashMap<>());
  private static void reg(int cat, int w, Block... bs) { for (Block b : bs) TABLE.put(b, new int[]{cat, w}); }
  static {
    reg(STORAGE, 3, Blocks.CHEST, Blocks.TRAPPED_CHEST, Blocks.BARREL);
    reg(STORAGE, 2, Blocks.ENDER_CHEST);
    reg(WORK, 1, Blocks.FURNACE, Blocks.BLAST_FURNACE, Blocks.SMOKER, Blocks.CRAFTING_TABLE);
    reg(WORK, 2, Blocks.ENCHANTING_TABLE, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL, Blocks.BREWING_STAND);
    reg(REDSTONE, 1, Blocks.HOPPER, Blocks.DISPENSER, Blocks.DROPPER, Blocks.PISTON, Blocks.STICKY_PISTON, Blocks.OBSERVER,
      Blocks.REPEATER, Blocks.COMPARATOR, Blocks.REDSTONE_LAMP);
    reg(VALUABLE, 8, Blocks.BEACON);
    reg(VALUABLE, 6, Blocks.NETHERITE_BLOCK);
    reg(VALUABLE, 4, Blocks.DIAMOND_BLOCK, Blocks.EMERALD_BLOCK, Blocks.RESPAWN_ANCHOR);
    reg(VALUABLE, 2, Blocks.GOLD_BLOCK);
    reg(SPAWNER, 4, Blocks.SPAWNER);
    reg(BUILDING, 1, Blocks.GLASS, Blocks.GLASS_PANE, Blocks.BRICKS);
    VILLAGE.addAll(List.of(Blocks.BELL, Blocks.COMPOSTER, Blocks.LOOM, Blocks.CARTOGRAPHY_TABLE, Blocks.FLETCHING_TABLE,
      Blocks.GRINDSTONE, Blocks.STONECUTTER, Blocks.SMITHING_TABLE, Blocks.LECTERN, Blocks.HAY_BLOCK));
  }
  /** {category, weight} or null */
  static int[] classify(BlockState s) {
    Block b = s.getBlock();
    int[] r = TABLE.get(b);
    if (r != null) return r;
    if (b instanceof BedBlock) return new int[]{BED, 2};
    if (b instanceof ShulkerBoxBlock) return new int[]{STORAGE, 3};
    if (s.isIn(net.minecraft.registry.tag.BlockTags.WOOL)) return new int[]{BUILDING, 1};
    return null;
  }
  static boolean relevant(BlockState s) { return classify(s) != null || VILLAGE.contains(s.getBlock()); }

  static final class Cell {
    final int cx, cz; final int[] counts = new int[CAT.length]; int score, village; double sx, sy, sz, sw; long scanned;
    Cell(int cx, int cz) { this.cx = cx; this.cz = cz; }
  }
  public static final class Result {
    public int score, village; public final int[] counts = new int[CAT.length]; public Vec3d center; public double dist; public int chunks; long id;
    public String summary() {
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < CAT.length; i++) if (counts[i] > 0) sb.append(sb.length() > 0 ? " " : "").append(CAT[i].charAt(0)).append(CAT[i].substring(1, Math.min(4, CAT[i].length())).toLowerCase(Locale.ROOT)).append('x').append(counts[i]);
      return sb.toString();
    }
  }

  private static BaseFinder instance;
  private final Map<Long, Cell> cells = new HashMap<>();
  private final Set<Long> announced = new HashSet<>();
  private List<Result> results = List.of();
  private ClientWorld lastWorld;
  private int clusterTimer, rrIndex;

  public BaseFinder() {
    super("Base Finder", Category.MISC, "Finds likely player-built bases in already-loaded chunks");
    instance = this;
    add(new Setting("Radius (chunks)", 8, 2, 24)).add(new Setting("Scan Speed", 2, 1, 8)).add(new Setting("Rescan (s)", 30, 5, 120, 5));
    add(new Setting("Min Score", 12, 3, 100)).add(new Setting("Min Types", 2, 1, 5));
    add(new Setting("Structure Bonus", true));
    add(new Setting("Min Y", -64, -64, 320, 8)).add(new Setting("Max Y", 320, -64, 320, 8));
    add(new Setting("Storage", true)).add(new Setting("Workstations", true)).add(new Setting("Beds", true)).add(new Setting("Redstone", true));
    add(new Setting("Valuables", true)).add(new Setting("Spawners", false)).add(new Setting("Building Blocks", false));
    add(new Setting("Ignore Villages", true)).add(new Setting("Remember Results", true));
    add(new Setting("HUD List", true)).add(new Setting("List Size", 5, 1, 10)).add(new Setting("Markers", true)).add(new Setting("Max Markers", 6, 1, 16));
    add(new Setting("Chat Alert", true));
  }

  @Override public void onEnable() { cells.clear(); announced.clear(); results = List.of(); }
  @Override public void onDisable() { cells.clear(); announced.clear(); results = List.of(); }

  @Override public void onTick(MinecraftClient mc) {
    if (mc.world != lastWorld) { lastWorld = mc.world; cells.clear(); announced.clear(); results = List.of(); }
    int rd = Math.min(get("Radius (chunks)").i(), mc.options.getViewDistance().getValue());
    int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
    long now = System.currentTimeMillis(), rescan = get("Rescan (s)").i() * 1000L;
    int budget = get("Scan Speed").i();

    // spiral-ish order: nearest rings first, one ring slice per call, cheap and allocation-free
    for (int ring = 0; ring <= rd && budget > 0; ring++) {
      int side = ring == 0 ? 1 : ring * 8;
      for (int k = 0; k < side && budget > 0; k++) {
        int dx, dz;
        if (ring == 0) { dx = 0; dz = 0; }
        else { int seg = k / (2 * ring); int off = k % (2 * ring) - ring + (seg == 1 || seg == 2 ? 1 : 0);
          switch (seg) { case 0 -> { dx = off; dz = -ring; } case 1 -> { dx = ring; dz = off; } case 2 -> { dx = -off; dz = ring; } default -> { dx = -ring; dz = -off; } } }
        int cx = pcx + dx, cz = pcz + dz; long key = ChunkPos2.key(cx, cz);
        Cell old = cells.get(key);
        if (old != null && now - old.scanned < rescan) continue;
        WorldChunk ch = mc.world.getChunkManager().getWorldChunk(cx, cz);
        if (ch == null) continue;
        cells.put(key, scan(ch, cx, cz, now));
        budget--;
      }
    }
    if (!get("Remember Results").on()) cells.keySet().removeIf(k -> Math.abs(ChunkPos2.x(k) - pcx) > rd + 1 || Math.abs(ChunkPos2.z(k) - pcz) > rd + 1);
    if (++clusterTimer >= 20) { clusterTimer = 0; rebuild(mc); }
  }

  private Cell scan(WorldChunk ch, int cx, int cz, long now) {
    Cell c = new Cell(cx, cz); c.scanned = now;
    boolean[] on = new boolean[CAT.length];
    for (int i = 0; i < CAT.length; i++) on[i] = get(FILTER_NAME[i]).on();
    ChunkScan.scan(ch, get("Min Y").i(), get("Max Y").i(), BaseFinder::relevant, (pos, state) -> {
      if (VILLAGE.contains(state.getBlock())) c.village++;
      int[] k = classify(state);
      if (k == null || !on[k[0]]) return;
      c.counts[k[0]]++; c.score += k[1];
      c.sx += pos.getX() * k[1]; c.sy += pos.getY() * k[1]; c.sz += pos.getZ() * k[1]; c.sw += k[1];
    });
    return c;
  }

  /** groups neighbouring chunk cells into clusters and filters them by score/type settings */
  private void rebuild(MinecraftClient mc) {
    Set<Long> seen = new HashSet<>(); List<Result> out = new ArrayList<>();
    int minScore = get("Min Score").i(), minTypes = get("Min Types").i(); boolean noVillage = get("Ignore Villages").on();
    for (Cell start : cells.values()) {
      if (start.score <= 0 || !seen.add(ChunkPos2.key(start.cx, start.cz))) continue;
      Result r = new Result(); r.id = ChunkPos2.key(start.cx, start.cz);
      double sx = 0, sy = 0, sz = 0, sw = 0;
      ArrayDeque<Cell> q = new ArrayDeque<>(); q.add(start);
      while (!q.isEmpty()) {
        Cell c = q.poll(); r.chunks++; r.score += c.score; r.village += c.village;
        for (int i = 0; i < CAT.length; i++) r.counts[i] += c.counts[i];
        sx += c.sx; sy += c.sy; sz += c.sz; sw += c.sw;
        r.id = Math.min(r.id, ChunkPos2.key(c.cx, c.cz));
        for (int dx = -1; dx <= 1; dx++) for (int dz = -1; dz <= 1; dz++) {
          if (dx == 0 && dz == 0) continue;
          long k = ChunkPos2.key(c.cx + dx, c.cz + dz); Cell n = cells.get(k);
          if (n != null && n.score > 0 && seen.add(k)) q.add(n);
        }
      }
      int types = 0; for (int n : r.counts) if (n > 0) types++;
      if (noVillage && r.village >= 2) continue;
      // Base-likelihood bonus: combinations are more informative than a pile of one block type.
      // This remains a heuristic; vanilla chunk data does not identify who placed a block.
      int storage = r.counts[STORAGE], work = r.counts[WORK], beds = r.counts[BED];
      int redstone = r.counts[REDSTONE], valuables = r.counts[VALUABLE], building = r.counts[BUILDING];
      int bonus = 0;
      if (get("Structure Bonus").on()) {
        bonus = Math.min(12, Math.max(0, types - 1) * 2);
        if (storage > 0 && work > 0) bonus += 5;
        if (storage > 0 && (beds > 0 || building >= 4)) bonus += 3;
        if (redstone >= 3 && storage > 0) bonus += 3;
        if (valuables > 0) bonus += 2;
      }
      r.score += bonus;
      if (r.score < minScore || types < minTypes || sw <= 0) continue;
      r.center = new Vec3d(sx / sw, sy / sw, sz / sw);
      r.dist = mc.player.getPos().distanceTo(r.center);
      out.add(r);
    }
    out.sort(Comparator.comparingDouble(a -> a.dist));
    results = out;
    if (get("Chat Alert").on()) for (Result r : out) if (announced.add(r.id))
      Chat.info("Base candidate: " + (int) r.center.x + " " + (int) r.center.y + " " + (int) r.center.z + " (" + (int) r.dist + " m, score " + r.score + ": " + r.summary() + ")");
  }

  @Override public void onHud(DrawContext ctx, float pt) {
    MinecraftClient mc = MinecraftClient.getInstance();
    int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
    if (get("Markers").on()) {
      int shown = 0;
      for (Result r : results) {
        if (shown >= get("Max Markers").i()) break;
        double[] p = Project.point(r.center, sw, sh);
        if (p == null || p[0] < 0 || p[0] > sw || p[1] < 0 || p[1] > sh) continue;
        shown++;
        int x = (int) p[0], y = (int) p[1];
        ctx.fill(x - 3, y - 3, x + 4, y + 4, Theme.accent());
        ctx.fill(x - 2, y - 2, x + 3, y + 3, 0xFF0C0A14);
        String t = (int) r.dist + "m  " + r.score;
        ctx.drawCenteredTextWithShadow(mc.textRenderer, t, x, y + 7, 0xFFEDE7FF);
      }
    }
    if (get("HUD List").on()) {
      int n = Math.min(results.size(), get("List Size").i()), x = 6, y = sh / 2 - 20;
      Draw.rrect(ctx, x - 3, y - 4, 190, 14 + Math.max(1, n) * 11, 3, 0xA00C0A14);
      ctx.drawText(mc.textRenderer, "Base Finder", x + 2, y, Theme.accentLight(), true);
      if (n == 0) ctx.drawText(mc.textRenderer, "scanning " + cells.size() + " chunks...", x + 2, y + 12, 0xFF8E86A8, false);
      for (int i = 0; i < n; i++) {
        Result r = results.get(i);
        ctx.drawText(mc.textRenderer, arrow(mc, r) + " " + (int) r.dist + "m  " + r.summary(), x + 2, y + 12 + i * 11, 0xFFEDE7FF, false);
      }
    }
  }

  private static String arrow(MinecraftClient mc, Result r) {
    double dx = r.center.x - mc.player.getX(), dz = r.center.z - mc.player.getZ();
    double rel = net.minecraft.util.math.MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(dz, dx)) - 90 - mc.player.getYaw());
    if (rel > -22.5 && rel <= 22.5) return "^"; if (rel > 22.5 && rel <= 67.5) return "^>"; if (rel > 67.5 && rel <= 112.5) return ">";
    if (rel > 112.5 && rel <= 157.5) return "v>"; if (rel > -67.5 && rel <= -22.5) return "<^"; if (rel > -112.5 && rel <= -67.5) return "<";
    if (rel > -157.5 && rel <= -112.5) return "<v"; return "v";
  }

  public static void command(String sub) {
    BaseFinder b = instance;
    if (b == null || !b.enabled) { Chat.info("Base Finder is off"); return; }
    if (sub.equals("clear")) { b.cells.clear(); b.announced.clear(); b.results = List.of(); Chat.info("Base Finder results cleared"); return; }
    if (b.results.isEmpty()) { Chat.info("No candidates yet (" + b.cells.size() + " chunks scanned)"); return; }
    for (Result r : b.results) Chat.info((int) r.center.x + " " + (int) r.center.y + " " + (int) r.center.z + "  " + (int) r.dist + "m  score " + r.score + "  " + r.summary());
  }

  /** packed chunk coordinates */
  static final class ChunkPos2 {
    static long key(int x, int z) { return ((long) x << 32) | (z & 0xFFFFFFFFL); }
    static int x(long k) { return (int) (k >> 32); }
    static int z(long k) { return (int) k; }
  }
}
