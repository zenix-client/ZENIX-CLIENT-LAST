package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.ui.BotsScreen;
import com.zenix.ui.ClickGui;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import java.util.List;

public final class MovementModules {
  private MovementModules() {}
  static final Category C = Category.MOVEMENT;

  public static void register(List<Module> l) {
    l.add(new AirStuck()); l.add(new Flight()); l.add(new Glide()); l.add(new GuiMove()); l.add(new Speed()); l.add(new Spider()); l.add(new Sprint()); MovementExtras.register(l);
    String hook = "Needs a packet/movement hook whose 1.21.4 signatures are not verified yet";
    for (String n : new String[]{"AutoDodge", "ElytraHelper", "ElytraMotion", "ElytraTarget", "SuperFirework", "TargetStrafe"}) l.add(Module.planned(n, C, "Not implemented yet"));
    l.add(Module.planned("Blink", C, hook)); l.add(Module.planned("NoSlow", C, hook)); l.add(Module.planned("NoWeb", C, hook));
  }

  /** horizontal unit vector of the pressed movement keys relative to the player's yaw, or null when standing still */
  static double[] dir(MinecraftClient mc) {
    int fw = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
    int st = (mc.options.leftKey.isPressed() ? 1 : 0) - (mc.options.rightKey.isPressed() ? 1 : 0);
    if (fw == 0 && st == 0) return null;
    double len = Math.sqrt(fw * fw + st * st), f = fw / len, s = st / len, y = Math.toRadians(mc.player.getYaw());
    return new double[]{-Math.sin(y) * f + Math.cos(y) * s, Math.cos(y) * f + Math.sin(y) * s};
  }

  public static class Sprint extends Module {
    public Sprint() { super("Sprint", C, "Keeps you sprinting while you move"); add(new Setting("Omni (any direction)", false)).add(new Setting("Keep In Water", true)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      boolean move = get("Omni (any direction)").on() ? dir(mc) != null : mc.options.forwardKey.isPressed();
      if (move && (get("Keep In Water").on() || !p.isTouchingWater()) && !p.isSneaking() && !p.horizontalCollision && p.getHungerManager().getFoodLevel() > 6) p.setSprinting(true);
    }
  }

  public static class Speed extends Module {
    public Speed() { super("Speed", C, "Faster ground/air movement"); add(new Setting("Speed", 0.35, 0.1, 1.5, 0.05)).add(new Setting("Air", true)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; double[] d = dir(mc);
      if (d == null || p.isTouchingWater() || p.isClimbing() || (!p.isOnGround() && !get("Air").on())) return;
      double s = get("Speed").value; Vec3d v = p.getVelocity();
      p.setVelocity(d[0] * s, v.y, d[1] * s);
    }
  }

  public static class Flight extends Module {
    public Flight() { super("Flight", C, "Motion flight: jump = up, sneak = down (servers with anti-cheat will kick)"); add(new Setting("Speed", 0.6, 0.1, 3.0, 0.1)).add(new Setting("Vertical", 0.5, 0.1, 2.0, 0.1)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; double[] d = dir(mc); double s = get("Speed").value;
      double vy = mc.options.jumpKey.isPressed() ? get("Vertical").value : mc.options.sneakKey.isPressed() ? -get("Vertical").value : 0;
      p.setVelocity(d == null ? 0 : d[0] * s, vy, d == null ? 0 : d[1] * s);
      p.fallDistance = 0;
    }
  }

  public static class Glide extends Module {
    public Glide() { super("Glide", C, "Slows your fall"); add(new Setting("Fall Speed", 0.08, 0.01, 0.4, 0.01)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; Vec3d v = p.getVelocity();
      if (p.isOnGround() || p.isTouchingWater() || p.isClimbing() || v.y >= 0 || p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) return;
      p.setVelocity(v.x, Math.max(v.y, -get("Fall Speed").value), v.z);
      p.fallDistance = 0;
    }
  }

  public static class Spider extends Module {
    public Spider() { super("Spider", C, "Climb walls while pushing into them"); add(new Setting("Climb Speed", 0.2, 0.1, 0.6, 0.05)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      if (p.horizontalCollision && dir(mc) != null) { Vec3d v = p.getVelocity(); p.setVelocity(v.x, get("Climb Speed").value, v.z); }
    }
  }

  public static class AirStuck extends Module {
    public AirStuck() { super("AirStuck", C, "Freezes your movement in place (client-side approximation: zero velocity)"); }
    @Override public void onTick(MinecraftClient mc) { mc.player.setVelocity(Vec3d.ZERO); }
  }

  public static class GuiMove extends Module {
    public GuiMove() { super("GuiMove", C, "Walk, jump and sprint while an inventory screen is open"); }
    @Override public void onTick(MinecraftClient mc) {
      var s = mc.currentScreen;
      if (s == null || s instanceof ClickGui || s instanceof BotsScreen || !(s instanceof HandledScreen<?>) || s instanceof AnvilScreen || s instanceof CreativeInventoryScreen) return;
      long w = mc.getWindow().getHandle();
      KeyBinding[] keys = {mc.options.forwardKey, mc.options.backKey, mc.options.leftKey, mc.options.rightKey, mc.options.jumpKey, mc.options.sprintKey};
      for (KeyBinding k : keys) k.setPressed(InputUtil.isKeyPressed(w, InputUtil.fromTranslationKey(k.getBoundKeyTranslationKey()).getCode()));
    }
  }
}
