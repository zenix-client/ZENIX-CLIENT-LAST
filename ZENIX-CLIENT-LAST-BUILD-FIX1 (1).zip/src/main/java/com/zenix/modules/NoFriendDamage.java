package com.zenix.modules;

import com.zenix.Module;
import com.zenix.util.Friends;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

/** Blocks every client-side attack on players in the friend list (.friend add <name>). Hooked in ClientPlayerInteractionManagerMixin. */
public class NoFriendDamage extends Module {
  static NoFriendDamage I;
  public NoFriendDamage() { super("NoFriendDamage", Category.COMBAT, "Never attack players from your friend list"); I = this; }
  public static boolean blocks(Entity e) {
    return I != null && I.enabled && e instanceof PlayerEntity p && Friends.is(p.getName().getString());
  }
}
