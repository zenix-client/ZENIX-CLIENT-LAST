package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import java.util.List;

public final class MovementExtras {
  private MovementExtras() {}
  static final Category C = Category.MOVEMENT;
  public static void register(List<Module> l) { l.add(new AutoJump()); l.add(new HighJump()); }

  public static class AutoJump extends Module {
    boolean pressed;
    public AutoJump() { super("AutoJump", C, "Jumps automatically while Aura has a target"); }
    @Override public void onTick(MinecraftClient mc) {
      if (pressed) { mc.options.jumpKey.setPressed(false); pressed = false; return; }
      if (CombatModules.Aura.target != null && mc.player.isOnGround()) { mc.options.jumpKey.setPressed(true); pressed = true; }
    }
    @Override public void onDisable() { MinecraftClient.getInstance().options.jumpKey.setPressed(false); pressed = false; }
  }

  public static class HighJump extends Module {
    boolean ground;
    public HighJump() { super("HighJump", C, "Multiplies the vertical speed of your jump"); add(new Setting("Multiplier", 1.5, 1.0, 3.0, 0.1)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player; Vec3d v = p.getVelocity();
      if (ground && !p.isOnGround() && v.y > 0.2 && v.y < 0.6 && mc.options.jumpKey.isPressed()) p.setVelocity(v.x, v.y * get("Multiplier").value, v.z);
      ground = p.isOnGround();
    }
  }
}
