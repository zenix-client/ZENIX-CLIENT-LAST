package com.zenix.modules;

import com.zenix.Module;
import com.zenix.Module.Category;
import com.zenix.Setting;
import com.zenix.ui.Draw;
import com.zenix.ui.Theme;
import com.zenix.util.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import java.util.*;

/** Render modules re-implemented from behaviour seen in the Obsidian reference (names/settings only, no code reused). */
public final class RenderExtras {
  private RenderExtras() {}
  static final Category C = Category.RENDER;
  public static void register(List<Module> l) {
    l.add(new EntityESP()); l.add(new Trajectories()); l.add(new JumpCircle()); l.add(new HitMarker()); l.add(new Trails());
    l.add(new FullBright()); l.add(new NoVignette()); l.add(new Removals()); l.add(new AntiInvisible());
  }

  // ------------------------------------------------------------------------------------------------ EntityESP
  public static class EntityESP extends Module {
    public EntityESP() {
      super("EntityESP", C, "2D boxes, names and health through walls");
      add(new Setting("Players", true)).add(new Setting("Mobs", false)).add(new Setting("Items", false));
      add(new Setting("Boxes", true)).add(new Setting("Tags", true)).add(new Setting("Range", 96, 8, 256, 8)).add(new Setting("Max Entities", 30, 5, 100, 5));
    }
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance(); int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(), n = 0, max = get("Max Entities").i();
      for (Entity e : mc.world.getEntities()) {
        if (n >= max) break;
        if (e == mc.player || mc.player.distanceTo(e) > get("Range").value) continue;
        boolean player = e instanceof PlayerEntity;
        if (player) { if (!get("Players").on() || CombatModules.AntiBot.isBot(e)) continue; }
        else if (e instanceof Monster) { if (!get("Mobs").on()) continue; }
        else if (e instanceof ItemEntity) { if (!get("Items").on()) continue; }
        else continue;
        double[] b = Project.box(RenderModules.boxAt(e, pt), sw, sh); if (b == null) continue;
        n++;
        int col = player && Friends.is(e.getName().getString()) ? Theme.GOOD : player ? Theme.accentLight() : Theme.accentDark();
        if (get("Boxes").on()) Draw.outline(ctx, (int) b[0], (int) b[1], (int) b[2], (int) b[3], col);
        if (get("Tags").on()) {
          String s = e instanceof ItemEntity ie ? ie.getStack().getName().getString() + " x" + ie.getStack().getCount() : e.getName().getString() + (e instanceof LivingEntity le ? "  " + String.format(Locale.ROOT, "%.0f", le.getHealth() / 2f) + "\u2665" : "");
          ctx.drawCenteredTextWithShadow(mc.textRenderer, s, (int) ((b[0] + b[2]) / 2), (int) b[1] - 10, 0xFFEDE7FF);
        }
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ Trajectories
  public static class Trajectories extends Module {
    public Trajectories() { super("Trajectories", C, "Predicts the flight path of pearls, potions, snowballs, bows and tridents in your hand"); add(new Setting("Steps", 80, 20, 150, 10)); }
    @Override public void onHud(DrawContext ctx, float pt) {
      MinecraftClient mc = MinecraftClient.getInstance(); PlayerEntity p = mc.player; ItemStack s = p.getMainHandStack();
      double speed, grav, pitchOff = 0;
      if (s.isOf(Items.ENDER_PEARL) || s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)) { speed = 1.5; grav = 0.03; }
      else if (s.isOf(Items.EXPERIENCE_BOTTLE)) { speed = 0.7; grav = 0.07; pitchOff = -20; }
      else if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION)) { speed = 0.5; grav = 0.05; pitchOff = -20; }
      else if (s.isOf(Items.BOW) && p.isUsingItem() && p.getActiveItem() == s) { speed = BowItem.getPullProgress(p.getItemUseTime()) * 3.0; grav = 0.05; }
      else if (s.isOf(Items.TRIDENT) && p.isUsingItem()) { speed = 2.5; grav = 0.05; }
      else return;
      if (speed < 0.2) return;
      double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch() + pitchOff);
      Vec3d dir = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
      Vec3d vel = dir.multiply(speed).add(p.getVelocity().x, p.isOnGround() ? 0 : p.getVelocity().y, p.getVelocity().z);
      Vec3d pos = p.getEyePos().subtract(0, 0.1, 0); int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
      double[] last = Project.point(pos, sw, sh); boolean hit = false; Vec3d end = pos;
      for (int i = 0; i < get("Steps").i(); i++) {
        Vec3d next = pos.add(vel);
        var r = mc.world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (r.getType() != HitResult.Type.MISS) { next = r.getPos(); hit = true; }
        double[] cur = Project.point(next, sw, sh);
        if (last != null && cur != null) Draw.line(ctx, last[0], last[1], cur[0], cur[1], hit ? Theme.GOOD : Theme.accentLight());
        last = cur; pos = next; end = next; if (hit) break;
        vel = vel.multiply(0.99).subtract(0, grav, 0);
      }
      if (hit && last != null) ctx.fill((int) last[0] - 2, (int) last[1] - 2, (int) last[0] + 3, (int) last[1] + 3, Theme.GOOD);
    }
  }

  // ------------------------------------------------------------------------------------------------ JumpCircle
  public static class JumpCircle extends Module {
    static final class Ring { double x, y, z; long t; }
    final List<Ring> rings = new ArrayList<>(); boolean ground = true;
    public JumpCircle() { super("JumpCircle", C, "Expanding ring where you jump"); add(new Setting("Radius", 1.8, 0.5, 5, 0.1)).add(new Setting("Duration (ms)", 700, 200, 2000, 100)); }
    @Override public void onTick(MinecraftClient mc) {
      PlayerEntity p = mc.player;
      if (ground && !p.isOnGround() && p.getVelocity().y > 0.1) { Ring r = new Ring(); r.x = p.getX(); r.y = p.getY() + 0.02; r.z = p.getZ(); r.t = System.currentTimeMillis(); rings.add(r); }
      ground = p.isOnGround(); long now = System.currentTimeMillis(); long d = get("Duration (ms)").i();
      rings.removeIf(r -> now - r.t > d);
    }
    @Override public void onHud(DrawContext ctx, float pt) {
      int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(); long now = System.currentTimeMillis(), d = get("Duration (ms)").i();
      for (Ring r : rings) {
        float k = (now - r.t) / (float) d; double rad = get("Radius").value * k; int col = Colors.alpha(Theme.accentLight(), 1f - k);
        double[] prev = null;
        for (int i = 0; i <= 20; i++) {
          double a = i * Math.PI * 2 / 20; double[] cur = Project.point(new Vec3d(r.x + Math.cos(a) * rad, r.y, r.z + Math.sin(a) * rad), sw, sh);
          if (prev != null && cur != null) Draw.line(ctx, prev[0], prev[1], cur[0], cur[1], col);
          prev = cur;
        }
      }
    }
  }

  // ------------------------------------------------------------------------------------------------ HitMarker
  public static class HitMarker extends Module {
    long last;
    public HitMarker() { super("HitMarker", C, "Marker around the crosshair when the targeted mob/player takes a hit"); add(new Setting("Size", 5, 2, 12)).add(new Setting("Duration (ms)", 300, 100, 1000, 50)); }
    @Override public void onTick(MinecraftClient mc) { if (mc.targetedEntity instanceof LivingEntity le && le.hurtTime >= 9) last = System.currentTimeMillis(); }
    @Override public void onHud(DrawContext ctx, float pt) {
      float k = (System.currentTimeMillis() - last) / (float) get("Duration (ms)").i(); if (k >= 1f) return;
      int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2, s = get("Size").i(), g = 3, col = Colors.alpha(0xFFFFFFFF, 1f - k);
      for (int sx = -1; sx <= 1; sx += 2) for (int sy = -1; sy <= 1; sy += 2) Draw.line(ctx, cx + sx * g, cy + sy * g, cx + sx * (g + s), cy + sy * (g + s), col);
    }
  }

  // ------------------------------------------------------------------------------------------------ Trails
  public static class Trails extends Module {
    final ArrayDeque<Vec3d> pts = new ArrayDeque<>();
    public Trails() { super("Trails", C, "Coloured trail behind you"); add(new Setting("Duration (ticks)", 40, 10, 120, 5)); }
    @Override public void onEnable() { pts.clear(); }
    @Override public void onTick(MinecraftClient mc) {
      pts.addLast(mc.player.getPos().add(0, 0.1, 0)); while (pts.size() > get("Duration (ticks)").i()) pts.pollFirst();
    }
    @Override public void onHud(DrawContext ctx, float pt) {
      if (mc().options.getPerspective().isFirstPerson()) return;
      int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight(), i = 0, n = pts.size(); double[] prev = null;
      for (Vec3d v : pts) { double[] cur = Project.point(v, sw, sh); if (prev != null && cur != null) Draw.line(ctx, prev[0], prev[1], cur[0], cur[1], Colors.alpha(Theme.accent(), i / (float) n)); prev = cur; i++; }
    }
    static MinecraftClient mc() { return MinecraftClient.getInstance(); }
  }

  // ------------------------------------------------------------------------------------------------ FullBright (night-vision effect, client side)
  public static class FullBright extends Module {
    int t; boolean added;
    public FullBright() { super("FullBright", C, "Everything is bright (client-side night vision effect)"); }
    @Override public void onTick(MinecraftClient mc) {
      if (t-- > 0) return; t = 100;
      mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false)); added = true;
    }
    @Override public void onDisable() { MinecraftClient mc = MinecraftClient.getInstance(); if (added && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION); added = false; t = 0; }
  }

  // ------------------------------------------------------------------------------------------------ flags read by optional mixins
  public static class NoVignette extends Module {
    static NoVignette I;
    public NoVignette() { super("NoVignette", C, "Removes the dark screen-edge vignette"); I = this; }
    public static boolean active() { return I != null && I.enabled; }
  }
  public static class AntiInvisible extends Module {
    static AntiInvisible I;
    public AntiInvisible() { super("AntiInvisible", C, "Invisible players are drawn as translucent ghosts"); I = this; }
    public static boolean active() { return I != null && I.enabled; }
  }
  public static class Removals extends Module {
    static Removals I; boolean saved; CloudRenderMode cloud; boolean shadows;
    public Removals() { super("Removals", C, "Hides fire overlay, in-wall overlay, clouds and entity shadows"); I = this; add(new Setting("Fire Overlay", true)).add(new Setting("In-Wall Overlay", true)).add(new Setting("Clouds", false)).add(new Setting("Shadows", false)); }
    public static boolean fire() { return I != null && I.enabled && I.get("Fire Overlay").on(); }
    public static boolean wall() { return I != null && I.enabled && I.get("In-Wall Overlay").on(); }
    @Override public void onTick(MinecraftClient mc) {
      var o = mc.options;
      if (!saved) { cloud = o.getCloudRenderMode().getValue(); shadows = o.getEntityShadows().getValue(); saved = true; }
      if (get("Clouds").on()) o.getCloudRenderMode().setValue(CloudRenderMode.OFF); else o.getCloudRenderMode().setValue(cloud);
      if (get("Shadows").on()) o.getEntityShadows().setValue(false); else o.getEntityShadows().setValue(shadows);
    }
    @Override public void onDisable() {
      MinecraftClient mc = MinecraftClient.getInstance();
      if (saved) { mc.options.getCloudRenderMode().setValue(cloud); mc.options.getEntityShadows().setValue(shadows); saved = false; }
    }
  }
}
