package com.zenix.bots;

import com.google.gson.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.zip.*;

/**
 * A real, separate network session (own socket + thread), speaking the Minecraft Java protocol 769 (1.21.4) directly.
 * It is NOT a FakePlayer and shares nothing with the game's own connection, so it never blocks the render/game thread.
 *
 * Limits (by design / by protocol):
 *  - offline-mode servers only: with online-mode the server asks for Mojang authentication, which a name-only bot cannot do;
 *  - the bot stays idle in the world (keep-alive, chat in/out). It does not move, load chunks or render anything;
 *  - captchas / bot filters are not solved.
 * Play-phase packet ids are protocol-769 values taken from memory of the protocol tables and are marked UNVERIFIED below;
 * login and configuration phase ids are stable since 1.20.2.
 */
public final class Bot {
  public enum State { IDLE, CONNECTING, LOGIN, CONFIG, ONLINE, DISCONNECTED, ERROR }

  static final int PROTOCOL = 769;
  // login / configuration phase (stable since 1.20.2)
  static final int L_HELLO = 0x00, L_ACK = 0x03, L_PLUGIN_RESP = 0x02;
  static final int C_CLIENT_INFO = 0x00, C_COOKIE_RESP = 0x01, C_FINISH_ACK = 0x03, C_KEEPALIVE = 0x04, C_PONG = 0x05, C_KNOWN_PACKS = 0x07;
  // play phase - UNVERIFIED against a live 1.21.4 server, see class comment
  static final int P_KEEPALIVE_IN = 0x27, P_DISCONNECT_IN = 0x1D, P_SYSTEM_CHAT_IN = 0x73, P_PLAYER_CHAT_IN = 0x39;
  static final int P_KEEPALIVE_OUT = 0x18, P_CHAT_OUT = 0x07, P_COMMAND_OUT = 0x05;

  public final int id;
  public String name;
  public String host = "";
  public int port = 25565;
  public volatile State state = State.IDLE;
  public volatile String info = "";
  public volatile long onlineSince;
  public final ConcurrentLinkedDeque<String> chat = new ConcurrentLinkedDeque<>();

  private volatile Thread thread;
  private volatile Socket socket;
  private volatile boolean stop;
  private volatile int threshold = -1;
  private volatile int phase; // 0 login, 1 config, 2 play
  private OutputStream out;
  private final Object outLock = new Object();
  volatile long lastAttempt;

  public Bot(int id, String name) { this.id = id; this.name = name; }

  public boolean running() { Thread t = thread; return t != null && t.isAlive(); }
  public void log(String s) { chat.add(s); while (chat.size() > 200) chat.pollFirst(); }

  /** @return null if started, otherwise the reason it did not start */
  public synchronized String connect() {
    if (running()) return "already running";
    if (host.isBlank()) return "enter a server address first";
    long wait = 3000 - (System.currentTimeMillis() - lastAttempt);
    if (wait > 0) return "wait " + (wait / 1000 + 1) + "s before reconnecting";
    lastAttempt = System.currentTimeMillis();
    stop = false; threshold = -1; phase = 0; info = "";
    state = State.CONNECTING;
    Thread t = new Thread(this::run, "zenix-bot-" + name);
    t.setDaemon(true); thread = t; t.start();
    return null;
  }

  public void disconnect() {
    stop = true;
    Socket s = socket;
    if (s != null) try { s.close(); } catch (IOException ignored) {}
    if (!running()) state = State.IDLE;
  }

  public boolean sendChat(String text) {
    if (state != State.ONLINE || text.isBlank()) return false;
    try {
      Buf b = new Buf();
      if (text.startsWith("/")) { b.varInt(P_COMMAND_OUT); b.string(text.substring(1)); }
      else {
        b.varInt(P_CHAT_OUT); b.string(text); b.longv(System.currentTimeMillis()); b.longv(0L);
        b.bool(false); b.varInt(0); b.bytes(new byte[3]);
      }
      send(b.toArray());
      log("> " + text);
      return true;
    } catch (IOException e) { info = "send failed: " + e.getMessage(); return false; }
  }

  // ---------------------------------------------------------------------------------------------------- session

  private void run() {
    try {
      Socket s = new Socket();
      socket = s;
      s.connect(new InetSocketAddress(host, port), 8000);
      s.setSoTimeout(30000); s.setTcpNoDelay(true);
      DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream(), 16384));
      out = new BufferedOutputStream(s.getOutputStream(), 8192);

      Buf hs = new Buf(); hs.varInt(0x00); hs.varInt(PROTOCOL); hs.string(host); hs.shortv(port); hs.varInt(2); send(hs.toArray());
      UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
      Buf lg = new Buf(); lg.varInt(L_HELLO); lg.string(name); lg.longv(uuid.getMostSignificantBits()); lg.longv(uuid.getLeastSignificantBits()); send(lg.toArray());
      state = State.LOGIN;

      while (!stop) {
        Pkt p = readPacket(in);
        if (p.body != null) handle(p.id, new Buf(p.body, p.off));
      }
    } catch (SocketTimeoutException e) {
      if (!stop) { state = State.ERROR; info = "timed out"; }
    } catch (IOException e) {
      if (!stop && state != State.ERROR) { state = State.DISCONNECTED; if (info.isEmpty()) info = e.getMessage() == null ? "connection closed" : e.getMessage(); }
    } catch (RuntimeException e) {
      if (!stop) { state = State.ERROR; info = e.getClass().getSimpleName() + ": " + e.getMessage(); }
    } finally {
      Socket s = socket; if (s != null) try { s.close(); } catch (IOException ignored) {}
      if (stop) state = State.IDLE; else if (state == State.ONLINE || state == State.CONFIG || state == State.LOGIN || state == State.CONNECTING) state = State.DISCONNECTED;
      log("* session ended" + (info.isEmpty() ? "" : ": " + info));
    }
  }

  private void handle(int id, Buf b) throws IOException {
    switch (phase) {
      case 0 -> {
        switch (id) {
          case 0x00 -> { info = jsonText(b.string()); state = State.DISCONNECTED; stop = true; }
          case 0x01 -> { info = "server is in online-mode: needs Mojang authentication (unsupported by name-only bots)"; state = State.ERROR; stop = true; }
          case 0x02 -> {
            Buf a = new Buf(); a.varInt(L_ACK); send(a.toArray());
            phase = 1; state = State.CONFIG;
            Buf ci = new Buf(); ci.varInt(C_CLIENT_INFO); ci.string("en_us"); ci.bytes(new byte[]{2}); ci.varInt(0); ci.bool(true);
            ci.bytes(new byte[]{0x7f}); ci.varInt(1); ci.bool(false); ci.bool(true); ci.varInt(0); send(ci.toArray());
          }
          case 0x03 -> threshold = b.varInt();
          case 0x04 -> { int mid = b.varInt(); Buf r = new Buf(); r.varInt(L_PLUGIN_RESP); r.varInt(mid); r.bool(false); send(r.toArray()); }
          default -> {}
        }
      }
      case 1 -> {
        switch (id) {
          case 0x00 -> { String ident = b.string(); Buf r = new Buf(); r.varInt(C_COOKIE_RESP); r.string(ident); r.bool(false); send(r.toArray()); }
          case 0x02 -> { info = nbtText(b); state = State.DISCONNECTED; stop = true; }
          case 0x03 -> { Buf r = new Buf(); r.varInt(C_FINISH_ACK); send(r.toArray()); phase = 2; state = State.ONLINE; onlineSince = System.currentTimeMillis(); log("* joined " + host + ":" + port); }
          case 0x04 -> { long k = b.longv(); Buf r = new Buf(); r.varInt(C_KEEPALIVE); r.longv(k); send(r.toArray()); }
          case 0x05 -> { int v = b.intv(); Buf r = new Buf(); r.varInt(C_PONG); r.intv(v); send(r.toArray()); }
          case 0x0E -> { Buf r = new Buf(); r.varInt(C_KNOWN_PACKS); r.varInt(0); send(r.toArray()); }
          default -> {}
        }
      }
      default -> {
        if (id == P_KEEPALIVE_IN) { long k = b.longv(); Buf r = new Buf(); r.varInt(P_KEEPALIVE_OUT); r.longv(k); send(r.toArray()); }
        else if (id == P_DISCONNECT_IN) { info = nbtText(b); state = State.DISCONNECTED; stop = true; }
        else if (id == P_SYSTEM_CHAT_IN) { String t = nbtText(b); if (!b.bool()) log(t); }
        else if (id == P_PLAYER_CHAT_IN) {
          try { b.varInt(); b.skip(16); b.varInt(); if (b.bool()) b.skip(256); String msg = b.string(); log("<chat> " + msg); }
          catch (RuntimeException ignored) { /* layout differs: ignore rather than guess */ }
        }
      }
    }
  }

  // ---------------------------------------------------------------------------------------------------- framing

  private static final class Pkt { int id, off; byte[] body; }

  private Pkt readPacket(DataInputStream in) throws IOException {
    int len = readVarInt(in);
    if (len <= 0 || len > 2_097_151) throw new IOException("bad packet length " + len);
    byte[] data = new byte[len]; in.readFully(data);
    Pkt p = new Pkt();
    Buf f = new Buf(data, 0);
    if (threshold >= 0) {
      int dl = f.varInt();
      if (dl == 0) { p.body = data; p.off = f.pos; }
      else {
        if (dl < 0 || dl > 8_388_608) throw new IOException("bad uncompressed size " + dl);
        Inflater inf = new Inflater();
        try {
          inf.setInput(data, f.pos, len - f.pos);
          byte[] head = new byte[Math.min(dl, 8)];
          int n = 0; while (n < head.length && !inf.finished()) { int r = inf.inflate(head, n, head.length - n); if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break; n += r; }
          Buf hb = new Buf(head, 0); p.id = hb.varInt();
          if (phase == 2 && !interesting(p.id)) return p; // skip big packets (chunks...) without inflating them fully
          byte[] full = new byte[dl]; System.arraycopy(head, 0, full, 0, n);
          int o = n; while (o < dl && !inf.finished()) { int r = inf.inflate(full, o, dl - o); if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break; o += r; }
          p.body = full; p.off = 0;
        } catch (DataFormatException e) { throw new IOException("bad compressed packet", e); }
        finally { inf.end(); }
      }
    } else { p.body = data; p.off = 0; }
    if (p.body != null) { Buf b = new Buf(p.body, p.off); p.id = b.varInt(); p.off = b.pos; }
    return p;
  }
  private static boolean interesting(int id) { return id == P_KEEPALIVE_IN || id == P_DISCONNECT_IN || id == P_SYSTEM_CHAT_IN || id == P_PLAYER_CHAT_IN; }

  private void send(byte[] body) throws IOException {
    synchronized (outLock) {
      OutputStream o = out; if (o == null) throw new IOException("not connected");
      int th = threshold;
      if (th >= 0) {
        if (body.length >= th) {
          Deflater d = new Deflater(); d.setInput(body); d.finish();
          ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] tmp = new byte[4096];
          while (!d.finished()) { int n = d.deflate(tmp); bo.write(tmp, 0, n); } d.end();
          Buf h = new Buf(); h.varInt(body.length);
          writeVarInt(o, h.size() + bo.size()); o.write(h.toArray()); bo.writeTo(o);
        } else { writeVarInt(o, 1 + body.length); o.write(0); o.write(body); }
      } else { writeVarInt(o, body.length); o.write(body); }
      o.flush();
    }
  }

  static int readVarInt(DataInputStream in) throws IOException {
    int v = 0, s = 0;
    while (true) { int b = in.readUnsignedByte(); v |= (b & 0x7F) << s; if ((b & 0x80) == 0) return v; s += 7; if (s > 35) throw new IOException("VarInt too big"); }
  }
  static void writeVarInt(OutputStream o, int v) throws IOException {
    while ((v & ~0x7F) != 0) { o.write((v & 0x7F) | 0x80); v >>>= 7; } o.write(v);
  }

  // ---------------------------------------------------------------------------------------------------- text decoding

  static String jsonText(String json) {
    try { return flatten(JsonParser.parseString(json)); } catch (RuntimeException e) { return json; }
  }
  private static String flatten(JsonElement e) {
    if (e.isJsonPrimitive()) return e.getAsString();
    if (e.isJsonArray()) { StringBuilder sb = new StringBuilder(); for (JsonElement x : e.getAsJsonArray()) sb.append(flatten(x)); return sb.toString(); }
    JsonObject o = e.getAsJsonObject(); StringBuilder sb = new StringBuilder();
    if (o.has("text")) sb.append(o.get("text").getAsString());
    else if (o.has("translate")) { sb.append(o.get("translate").getAsString()); if (o.has("with")) sb.append(' ').append(flatten(o.get("with"))); }
    if (o.has("extra")) sb.append(flatten(o.get("extra")));
    return sb.toString();
  }

  /** Network text component: nameless NBT (a string tag or a compound with text / translate / with / extra). */
  static String nbtText(Buf b) throws IOException {
    int t = b.u8();
    return flatten(readNbt(b, t, 0));
  }
  @SuppressWarnings("unchecked")
  private static String flatten(Object v) {
    if (v instanceof String s) return s;
    if (v instanceof List<?> l) { StringBuilder sb = new StringBuilder(); for (Object o : l) sb.append(flatten(o)); return sb.toString(); }
    if (v instanceof Map<?, ?> m) {
      Map<String, Object> mm = (Map<String, Object>) m; StringBuilder sb = new StringBuilder();
      if (mm.get("text") != null) sb.append(flatten(mm.get("text")));
      else if (mm.get("translate") != null) { sb.append(flatten(mm.get("translate"))); if (mm.get("with") != null) sb.append(' ').append(flatten(mm.get("with"))); }
      if (mm.get("extra") != null) sb.append(flatten(mm.get("extra")));
      return sb.toString();
    }
    return v == null ? "" : String.valueOf(v);
  }
  private static Object readNbt(Buf b, int t, int depth) throws IOException {
    if (depth > 48) throw new IOException("nbt too deep");
    switch (t) {
      case 0: return null;
      case 1: return b.u8();
      case 2: return b.u16();
      case 3: return b.intv();
      case 4: return b.longv();
      case 5: return b.intv();
      case 6: return b.longv();
      case 7: b.skip(b.intv()); return null;
      case 8: return b.utf();
      case 9: { int et = b.u8(), n = b.intv(); if (n < 0 || n > 65536) throw new IOException("bad nbt list"); List<Object> l = new ArrayList<>(); for (int i = 0; i < n; i++) l.add(readNbt(b, et, depth + 1)); return l; }
      case 10: { Map<String, Object> m = new HashMap<>(); while (true) { int tt = b.u8(); if (tt == 0) break; String k = b.utf(); m.put(k, readNbt(b, tt, depth + 1)); } return m; }
      case 11: b.skip(b.intv() * 4); return null;
      case 12: b.skip(b.intv() * 8); return null;
      default: throw new IOException("bad nbt tag " + t);
    }
  }

  // ---------------------------------------------------------------------------------------------------- byte buffer

  static final class Buf {
    byte[] a; int pos; int size;
    Buf() { a = new byte[64]; }
    Buf(byte[] data, int off) { a = data; pos = off; size = data.length; }
    int size() { return size; }
    byte[] toArray() { return Arrays.copyOf(a, size); }
    private void ensure(int n) { if (size + n > a.length) a = Arrays.copyOf(a, Math.max(a.length * 2, size + n)); }
    void bytes(byte[] x) { ensure(x.length); System.arraycopy(x, 0, a, size, x.length); size += x.length; }
    void u8v(int v) { ensure(1); a[size++] = (byte) v; }
    void varInt(int v) { while ((v & ~0x7F) != 0) { u8v((v & 0x7F) | 0x80); v >>>= 7; } u8v(v); }
    void string(String s) { byte[] x = s.getBytes(StandardCharsets.UTF_8); varInt(x.length); bytes(x); }
    void shortv(int v) { u8v(v >> 8); u8v(v); }
    void intv(int v) { u8v(v >> 24); u8v(v >> 16); u8v(v >> 8); u8v(v); }
    void longv(long v) { for (int i = 56; i >= 0; i -= 8) u8v((int) (v >> i)); }
    void bool(boolean v) { u8v(v ? 1 : 0); }

    private void need(int n) { if (pos + n > size || n < 0) throw new IllegalStateException("packet underrun"); }
    int u8() { need(1); return a[pos++] & 255; }
    int u16() { return (u8() << 8) | u8(); }
    int intv() { return (u8() << 24) | (u8() << 16) | (u8() << 8) | u8(); }
    long longv() { long v = 0; for (int i = 0; i < 8; i++) v = (v << 8) | u8(); return v; }
    boolean bool() { return u8() != 0; }
    void skip(int n) { need(n); pos += n; }
    int varInt() { int v = 0, s = 0; while (true) { int b = u8(); v |= (b & 0x7F) << s; if ((b & 0x80) == 0) return v; s += 7; if (s > 35) throw new IllegalStateException("VarInt too big"); } }
    String string() { int n = varInt(); need(n); String s = new String(a, pos, n, StandardCharsets.UTF_8); pos += n; return s; }
    String utf() { int n = u16(); need(n); String s = new String(a, pos, n, StandardCharsets.UTF_8); pos += n; return s; }
  }
}
