package com.zenix.bots;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;

/** Owns all bot sessions. Capped on purpose: this is for AFK/test accounts on servers you control or have permission for, not for flooding. */
public final class BotManager {
  private BotManager() {}
  public static final int MAX_BOTS = 5;
  public static final List<Bot> BOTS = new CopyOnWriteArrayList<>();
  public static int selected = -1;
  private static int nextId = 1;
  private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
  private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("zenix-bots.json");

  public static Bot selected() { for (Bot b : BOTS) if (b.id == selected) return b; return null; }

  /** @return null on success or an error text */
  public static String add(String name) {
    if (BOTS.size() >= MAX_BOTS) return "limit of " + MAX_BOTS + " bots reached";
    if (!NAME.matcher(name).matches()) return "name must be 3-16 chars: letters, digits, _";
    for (Bot b : BOTS) if (b.name.equalsIgnoreCase(name)) return "a bot with this name already exists";
    Bot b = new Bot(nextId++, name);
    BOTS.add(b); selected = b.id; save();
    return null;
  }
  public static void remove(Bot b) {
    b.disconnect(); BOTS.remove(b);
    if (selected == b.id) selected = BOTS.isEmpty() ? -1 : BOTS.get(0).id;
    save();
  }
  public static void shutdown() { for (Bot b : BOTS) b.disconnect(); }

  public static void load() {
    try {
      if (!Files.exists(FILE)) return;
      for (JsonElement e : JsonParser.parseString(Files.readString(FILE)).getAsJsonArray()) {
        JsonObject o = e.getAsJsonObject(); Bot b = new Bot(nextId++, o.get("name").getAsString());
        if (o.has("host")) b.host = o.get("host").getAsString();
        if (o.has("port")) b.port = o.get("port").getAsInt();
        BOTS.add(b);
      }
      if (!BOTS.isEmpty()) selected = BOTS.get(0).id;
    } catch (Exception e) { e.printStackTrace(); }
  }
  public static void save() {
    try {
      JsonArray a = new JsonArray();
      for (Bot b : BOTS) { JsonObject o = new JsonObject(); o.addProperty("name", b.name); o.addProperty("host", b.host); o.addProperty("port", b.port); a.add(o); }
      Files.writeString(FILE, a.toString());
    } catch (Exception e) { e.printStackTrace(); }
  }
}
