package com.zenix;

import com.google.gson.*;
import com.zenix.Module.Category;
import com.zenix.bots.BotManager;
import com.zenix.modules.*;
import com.zenix.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.util.*;

public class Zenix implements ClientModInitializer {
  public static final Logger LOG = LoggerFactory.getLogger("zenix");
  public static final List<Module> MODULES = new ArrayList<>();
  public static Ambience ambience;
  public static Module arrows, clickgui;
  static final Path CFG = FabricLoader.getInstance().getConfigDir().resolve("zenix.json");
  private static final List<Runnable> LATER = new ArrayList<>();
  /** Runs on the next client tick (needed e.g. to open a screen after ChatScreen closed itself). */
  public static void later(Runnable r) { synchronized (LATER) { LATER.add(r); } }
  static final boolean[] down = new boolean[GLFW.GLFW_KEY_LAST + 1];

  @Override public void onInitializeClient() {
    CombatModules.register(MODULES);
    MovementModules.register(MODULES);
    PlayerModules.register(MODULES);
    RenderModules.register(MODULES);
    MiscModules.register(MODULES);
    ambience = (Ambience) byName("Ambience");
    arrows = byName("Arrows");
    clickgui = byName("ClickGUI");
    load();
    Friends.load();
    Waypoints.load();
    BotManager.load();
    ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    HudRenderCallback.EVENT.register(this::hud);
    ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
      String s = msg.getString();
      for (Module m : MODULES) if (m.enabled) { try { m.onChat(s); } catch (Throwable t) { fail(m, t); } }
    });
    Runtime.getRuntime().addShutdownHook(new Thread(() -> { save(); BotManager.save(); BotManager.shutdown(); }));
    LOG.info("ZENIX CLIENT loaded: {} modules ({} implemented)", MODULES.size(), MODULES.stream().filter(m -> !m.planned).count());
  }

  /** Lookup ignoring case and spaces ("basefinder" finds "Base Finder"). */
  public static Module byName(String n) {
    String k = n.replace(" ", "").toLowerCase(Locale.ROOT);
    for (Module m : MODULES) if (m.name.replace(" ", "").toLowerCase(Locale.ROOT).equals(k)) return m;
    return null;
  }

  static void fail(Module m, Throwable t) {
    LOG.error("ZENIX: module {} crashed and was disabled", m.name, t);
    m.enabled = false;
    try { m.onDisable(); } catch (Throwable ignored) {}
    Chat.info("\u00a7c" + m.name + " disabled after an error: " + t.getClass().getSimpleName());
  }

  void tick(MinecraftClient mc) {
    if (mc.getWindow() == null) return;
    List<Runnable> run; synchronized (LATER) { run = new ArrayList<>(LATER); LATER.clear(); }
    for (Runnable r : run) { try { r.run(); } catch (Throwable t) { LOG.error("ZENIX: deferred task failed", t); } }
    long w = mc.getWindow().getHandle();
    if (mc.currentScreen == null) for (Module m : MODULES) if (m.key > 0 && m.key < down.length && !m.planned) {
      boolean d = InputUtil.isKeyPressed(w, m.key);
      if (d && !down[m.key]) m.onKey(mc);
      down[m.key] = d;
    }
    if (mc.world == null || mc.player == null) return;
    for (Module m : MODULES) if (m.enabled) { try { m.onTick(mc); } catch (Throwable t) { fail(m, t); } }
  }

  void hud(DrawContext ctx, RenderTickCounter tc) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.world == null || mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
    float pt = tc.getTickDelta(true);
    for (Module m : MODULES) if (m.enabled) { try { m.onHud(ctx, pt); } catch (Throwable t) { fail(m, t); } }
  }

  public static void save() {
    try {
      JsonObject o = new JsonObject();
      for (Module m : MODULES) {
        JsonObject j = new JsonObject(); j.addProperty("enabled", m.enabled); j.addProperty("key", m.key);
        for (Setting s : m.settings) j.addProperty(s.name, s.value);
        o.add(m.name, j);
      }
      Files.writeString(CFG, new GsonBuilder().setPrettyPrinting().create().toJson(o));
    } catch (Exception e) { LOG.error("ZENIX: config save failed", e); }
  }

  static void load() {
    try {
      if (!Files.exists(CFG)) return;
      JsonObject o = JsonParser.parseString(Files.readString(CFG)).getAsJsonObject();
      for (Module m : MODULES) if (o.has(m.name)) {
        JsonObject j = o.getAsJsonObject(m.name);
        if (j.has("enabled") && !m.planned && !m.oneShot) m.enabled = j.get("enabled").getAsBoolean();
        if (j.has("key")) m.key = j.get("key").getAsInt();
        for (Setting s : m.settings) if (j.has(s.name)) s.set(j.get(s.name).getAsDouble());
      }
      // ClickGUI itself is always "on" (it only opens the screen)
      if (clickgui != null) clickgui.enabled = true;
    } catch (Exception e) { LOG.error("ZENIX: config load failed", e); }
  }
}
