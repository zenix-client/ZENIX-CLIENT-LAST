package com.zenix.gui;

import com.zenix.ui.Fnt;
import com.zenix.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SplashScreen extends Screen {
  public SplashScreen() { super(Text.literal("ZENIX")); }
  @Override public boolean shouldCloseOnEsc() { return false; }
  @Override public boolean mouseClicked(double x, double y, int b) { client.setScreen(new MainMenu()); return true; }
  @Override public boolean keyPressed(int k, int s, int m) { client.setScreen(new MainMenu()); return true; }
  @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}
  @Override public void render(DrawContext c, int mx, int my, float d) {
    paint(c, width, height);
    double t = System.currentTimeMillis() / 1000.0;
    LocalDateTime n = LocalDateTime.now();
    var tr = textRenderer;
    c.getMatrices().push(); c.getMatrices().translate(width / 2f, height / 2f - 44, 0); c.getMatrices().scale(4, 4, 1);
    c.drawCenteredTextWithShadow(tr, Fnt.t(n.format(DateTimeFormatter.ofPattern("HH:mm"))), 0, 0, 0xFFFFFFFF); c.getMatrices().pop();
    c.drawCenteredTextWithShadow(tr, Fnt.t(n.format(DateTimeFormatter.ofPattern("d MMMM yyyy"))), width / 2, height / 2 - 8, 0xFF9C94B8);
    c.drawCenteredTextWithShadow(tr, Fnt.t("Welcome, " + client.getSession().getUsername()), width / 2, height / 2 + 12, Theme.accentLight());
    c.drawCenteredTextWithShadow(tr, Fnt.t("ZENIX CLIENT"), width / 2, height / 2 + 28, 0xFF6F6890);
    int a = (int) (120 + 100 * Math.sin(t * 2));
    c.drawCenteredTextWithShadow(tr, Fnt.t("Tap anywhere to continue"), width / 2, height - 30, (a << 24) | 0xA78BFA);
  }
  /** Cheap animated background: 3 sine ribbons + 40 particles, only fill() calls. Purple only. */
  public static void paint(DrawContext c, int w, int h) {
    c.fill(0, 0, w, h, 0xFF05030A);
    double t = System.currentTimeMillis() / 1000.0;
    int[] rib = {0x7C3AED, 0x8B5CF6, 0x6D28D9};
    for (int r = 0; r < 3; r++) for (int x = 0; x < w; x += 4) {
      double y = h * (0.35 + 0.15 * r) + Math.sin(x * 0.012 + t * (0.5 + 0.2 * r) + r * 2) * h * 0.08 + Math.sin(x * 0.03 - t) * 6;
      for (int k = 0; k < 14; k++) { int a = (int) (38 * (1 - k / 14.0)); c.fill(x, (int) y + k * 2, x + 4, (int) y + k * 2 + 2, (a << 24) | rib[r]); }
    }
    for (int i = 0; i < 40; i++) {
      double px = (Math.sin(i * 12.9898) * 0.5 + 0.5) * w + Math.sin(t * 0.3 + i) * 20;
      double py = ((Math.cos(i * 78.233) * 0.5 + 0.5) * h - t * (8 + i % 5 * 3)) % h; if (py < 0) py += h;
      int a = (int) (60 + 60 * Math.sin(t * 1.5 + i)); c.fill((int) px, (int) py, (int) px + 2, (int) py + 2, (a << 24) | 0xC4B5FD);
    }
  }
}
