package com.zenix.mixin;

import com.zenix.modules.RenderExtras;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public class InGameHudMixin {
  @Inject(method = "renderVignetteOverlay", at = @At("HEAD"), cancellable = true)
  private void zenix$noVignette(CallbackInfo ci) { if (RenderExtras.NoVignette.active()) ci.cancel(); }
}
