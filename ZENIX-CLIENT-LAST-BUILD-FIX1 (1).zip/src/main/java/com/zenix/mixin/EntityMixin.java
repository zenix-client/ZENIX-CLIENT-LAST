package com.zenix.mixin;

import com.zenix.modules.PlayerExtras;
import com.zenix.modules.RenderExtras;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public class EntityMixin {
  @Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
  private void zenix$noPush(CallbackInfo ci) {
    if ((Object) this instanceof ClientPlayerEntity && PlayerExtras.NoPush.active()) ci.cancel();
  }
  @Inject(method = "isInvisibleTo", at = @At("RETURN"), cancellable = true)
  private void zenix$seeInvisible(CallbackInfoReturnable<Boolean> cir) {
    if (RenderExtras.AntiInvisible.active()) cir.setReturnValue(false);
  }
}
