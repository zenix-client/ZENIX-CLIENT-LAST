package com.zenix.mixin;

import com.zenix.Zenix;
import com.zenix.modules.Ambience;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class ClientWorldMixin {
  /** Sky colour override for Ambience. require = 0: if the target is missing in this build the game still starts (sky setting then has no effect). */
  @Inject(method = "getSkyColor", at = @At("RETURN"), cancellable = true, require = 0)
  private void zenix$sky(CallbackInfoReturnable<Vec3d> cir) {
    Ambience a = Zenix.ambience;
    if (a == null || !a.skyActive()) return;
    float[] c = a.skyRgb();
    cir.setReturnValue(new Vec3d(c[0], c[1], c[2]));
  }
}
