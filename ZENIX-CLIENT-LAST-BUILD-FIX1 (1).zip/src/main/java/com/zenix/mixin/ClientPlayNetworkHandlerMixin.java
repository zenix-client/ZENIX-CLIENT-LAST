package com.zenix.mixin;

import com.zenix.util.CommandManager;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPlayNetworkHandlerMixin {
  @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true, require = 0)
  private void zenix$commands(String content, CallbackInfo ci) {
    if (content != null && content.length() > 1 && content.charAt(0) == '.' && CommandManager.handle(content)) ci.cancel();
  }
}
