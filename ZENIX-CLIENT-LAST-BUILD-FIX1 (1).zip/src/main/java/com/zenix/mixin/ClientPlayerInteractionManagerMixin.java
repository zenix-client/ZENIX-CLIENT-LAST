package com.zenix.mixin;

import com.zenix.modules.NoFriendDamage;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {
  @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true, require = 0)
  private void zenix$noFriendDamage(PlayerEntity player, Entity target, CallbackInfo ci) {
    if (NoFriendDamage.blocks(target)) ci.cancel();
  }
}
