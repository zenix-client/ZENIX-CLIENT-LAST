# ZENIX CLIENT - status (MC 1.21.4, Fabric, Java 21)

**Build status: NOT BUILT.** The authoring environment had no Minecraft/Fabric/Gradle access (offline, no javac).
Source syntax was parsed with javac (0 syntax errors) and the bot network code was compiled and run against a mock server,
but nothing that touches Minecraft classes has been compiled against the real 1.21.4 mappings. Build it with GitHub Actions
(.github/workflows/build.yml) and fix any compile errors reported there.

## Implemented (58 modules + Bots; 39 of them are from your 100-name list)
Combat: AntiBot, Aura, AutoArmor, AutoTotem, ClickPearl, Criticals, NoFriendDamage, Suicide, TriggerBot
Movement: AirStuck, Flight, Glide, GuiMove, Speed, Spider, Sprint
Player: AntiAFK, AutoExp, AutoRespawn, AutoTool, ChestStealer, Nuker, Optimize
Render: Ambience, Arrows, Base Finder, BlockESP, TargetESP, Tracers, Waypoint, WorldTime
Misc: AutoLeave, AutoTPAccept, ClickGUI
Added from the Obsidian audit (docs/OBSIDIAN_AUDIT.md): AimAssist, AimBot, ItemRelease, AutoExplosion, AutoSwap, AutoJump, HighJump, AutoEat, AutoFish, HelpMessage, NoDelay, NoPush, EntityESP, Trajectories, JumpCircle, HitMarker, Trails, FullBright, NoVignette, Removals, AntiInvisible, DeathCoord, LeaveTracker, EcOpen
Other: Bots tab (real network sessions), chat commands (.help .toggle .bind .friend .waypoint .bf .bots), friends list, waypoints.

## Font
ZENIX screens (main menu, ClickGUI, Bots) use a bitmap font generated from Montserrat Bold (SIL OFL) by tools/gen_font.py - Latin + Cyrillic, no FreeType needed on Android. The rest of the game keeps the vanilla font.

## Mixins
zenix.mixins.json (required): fog (BackgroundRenderer), title-screen replacement. zenix-optional.mixins.json (required=false, defaultRequire=0): sky colour, chat commands, friend protection, NoPush/AntiInvisible, NoVignette, Removals, NoDelay accessors. If one of those fails to apply on 1.21.4 the game still starts and only that feature is dead.

## Not implemented (shown as SOON in the GUI, cannot be enabled)
See `Module.planned(...)` lines in modules/*Modules.java - each has a reason string shown in the GUI.

## Known limits
- Ambience: fog/time/weather use known injection points; sky colour (ClientWorldMixin, require=0) is unverified in-game.
- Base Finder: only scans chunks the server already sent (render distance). Heuristic score; villages/ruins can false-positive.
  Cannot see unloaded chunks or anything the server hides (anti-xray etc).
- ESP/tracers use CPU projection with the FOV option; approximate while sprinting (dynamic FOV).
- Bots: offline-mode servers only, idle in the world (no movement), no captcha/bot-filter solving, max 5.
  Play-phase packet ids are unverified against a live server; login/config phases tested only against a mock.
  Bots tab: Overview only; Modules/Configs/Settings/Proxy tabs are placeholders.
- Flight/Speed/Aura etc. will be flagged or kicked by servers with anti-cheat; no bypasses are claimed.

## Unverified API calls to check first if the build fails
RenderTickCounter.getTickDelta(boolean), ClientReceiveMessageEvents.GAME, Entity.getLerpedPos/getEyePos, LivingEntity.canSee,
PlayerInventory.selectedSlot (public field in 1.21.4), Entity.fallDistance, KeyBinding.setPressed/getBoundKeyTranslationKey,
ChunkSection.hasAny / WorldChunk.getSectionArray / ChunkManager.getWorldChunk, GameOptions getters in Optimize,
ClientPlayNetworkHandler.getPlayerListEntry/sendChatCommand/getConnection().disconnect(Text), MinecraftClient.targetedEntity,
getSession().getUsername(), AbstractBlockState.getHardness, LivingEntity.hasStatusEffect(StatusEffects.*).

## Install (Zalith Launcher)
1. Get the JAR from the GitHub Actions run: Actions > latest run > Artifacts > zenix-client-jar.
2. Zalith: create a Fabric 1.21.4 profile (loader >= 0.16), Java 21.
3. Put Fabric API 0.119.x+1.21.4 and zenix-client-*.jar into the profile's mods folder.
4. Launch. Right Shift (or the CLICKGUI card on the main menu) opens the ClickGUI. Config: config/zenix.json.
