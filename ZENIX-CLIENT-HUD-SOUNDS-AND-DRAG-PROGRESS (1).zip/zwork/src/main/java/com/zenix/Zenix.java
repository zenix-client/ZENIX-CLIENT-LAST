package com.zenix;

import com.google.gson.*;
import com.zenix.Module.Category;
import com.zenix.bots.BotManager;
import com.zenix.modules.*;
import com.zenix.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.system.MemoryStack;
import java.nio.DoubleBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.nio.file.*;
import java.util.*;

public class Zenix implements ClientModInitializer {
  public static final Logger LOG = LoggerFactory.getLogger("zenix");
  public static final List<Module> MODULES = new ArrayList<>();
  public static Ambience ambience;
  public static Module arrows, clickgui;
  static final Path CFG = FabricLoader.getInstance().getConfigDir().resolve("zenix.json");
  private static final List<Runnable> LATER = new ArrayList<>();
  private static String toastText = "";
  private static long toastUntil = 0L;
  private static boolean toastEnabled = true;
  private static int toastX = Integer.MIN_VALUE, toastY = 12;
  private static boolean toastDragging = false, toastMouseWasDown = false;
  private static double toastDragOffsetX, toastDragOffsetY;
  /** Plays the selected interface sound. Kept separate from module notification sounds. */
  public static void playMenuClick() {
    Module ui = byName("HUD");
    if (ui == null) return;
    try {
      if (!ui.get("Звуки меню").on()) return;
      float volume = Math.max(0f, Math.min(1f, ui.get("Громкость").f() / 100f));
      if (volume <= 0f) return;
      String style = ui.get("Стиль звука").mode();
      MinecraftClient mc = MinecraftClient.getInstance();
      if (mc == null) return;
      switch (style) {
        case "Glass" -> mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME, 1.25f, volume));
        case "Digital" -> mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_NOTE_BLOCK_PLING, 1.65f, volume));
        case "Mechanical" -> mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.BLOCK_LEVER_CLICK, 0.8f, volume));
        default -> mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.UI_BUTTON_CLICK, 1.0f, volume));
      }
    } catch (Exception ignored) {}
  }

  public static void moduleToggled(Module module, boolean state) {
    Module ui = byName("HUD");
    boolean notifications = true;
    boolean notificationSound = true;
    try {
      if (ui != null) {
        notifications = ui.get("Уведомления").on();
        notificationSound = ui.get("Звук уведомления").on();
      }
    } catch (Exception ignored) {}
    if (!notifications) return;
    if (notificationSound && ui != null) {
      try {
        float volume = Math.max(0f, Math.min(1f, ui.get("Громкость").f() / 100f));
        if (volume > 0f) {
          MinecraftClient mc = MinecraftClient.getInstance();
          if (mc != null) mc.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.25f, volume));
        }
      } catch (Exception ignored) {}
    }
    toastText = module.name + "  " + (state ? "ON" : "OFF");
    long duration = 1900L;
    if (ui != null) try { duration = Math.round(ui.get("Длительность (сек)").f() * 1000.0); } catch (Exception ignored) {}
    toastUntil = System.currentTimeMillis() + duration;
  }
  /** Runs on the next client tick (needed e.g. to open a screen after ChatScreen closed itself). */
  public static void later(Runnable r) { synchronized (LATER) { LATER.add(r); } }
  static final boolean[] down = new boolean[GLFW.GLFW_KEY_LAST + 1];

  @Override public void onInitializeClient() {
    CombatModules.register(MODULES);
    MovementModules.register(MODULES);
    PlayerModules.register(MODULES);
    RenderModules.register(MODULES);
    MiscModules.register(MODULES);
    ambience = (Ambience) byName("Ambience");
    arrows = byName("Arrows");
    clickgui = byName("ClickGUI");
    load();
    Friends.load();
    Waypoints.load();
    BotManager.load();
    ClientTickEvents.END_CLIENT_TICK.register(this::tick);
    HudRenderCallback.EVENT.register(this::hud);
    ClientReceiveMessageEvents.GAME.register((msg, overlay) -> {
      String s = msg.getString();
      for (Module m : MODULES) if (m.enabled) { try { m.onChat(s); } catch (Throwable t) { fail(m, t); } }
    });
    Runtime.getRuntime().addShutdownHook(new Thread(() -> { save(); BotManager.save(); BotManager.shutdown(); }));
    LOG.info("ZENIX CLIENT loaded: {} modules ({} implemented)", MODULES.size(), MODULES.stream().filter(m -> !m.planned).count());
  }

  /** Lookup ignoring case and spaces ("basefinder" finds "Base Finder"). */
  public static Module byName(String n) {
    String k = n.replace(" ", "").toLowerCase(Locale.ROOT);
    for (Module m : MODULES) if (m.name.replace(" ", "").toLowerCase(Locale.ROOT).equals(k)) return m;
    return null;
  }

  static void fail(Module m, Throwable t) {
    LOG.error("ZENIX: module {} crashed and was disabled", m.name, t);
    m.enabled = false;
    try { m.onDisable(); } catch (Throwable ignored) {}
    Chat.info("\u00a7c" + m.name + " disabled after an error: " + t.getClass().getSimpleName());
  }

  void tick(MinecraftClient mc) {
    if (mc.getWindow() == null) return;
    List<Runnable> run; synchronized (LATER) { run = new ArrayList<>(LATER); LATER.clear(); }
    for (Runnable r : run) { try { r.run(); } catch (Throwable t) { LOG.error("ZENIX: deferred task failed", t); } }
    updateToastDrag(mc);
    long w = mc.getWindow().getHandle();
    if (mc.currentScreen == null) for (Module m : MODULES) if (m.key > 0 && m.key < down.length && !m.planned) {
      boolean d = InputUtil.isKeyPressed(w, m.key);
      if (d && !down[m.key]) m.onKey(mc);
      down[m.key] = d;
    }
    if (mc.world == null || mc.player == null) return;
    for (Module m : MODULES) if (m.enabled) { try { m.onTick(mc); } catch (Throwable t) { fail(m, t); } }
  }

  void hud(DrawContext ctx, RenderTickCounter tc) {
    MinecraftClient mc = MinecraftClient.getInstance();
    if (mc.options.hudHidden) return;
    // Toasts remain visible while chat is open, so their position can be checked before returning to gameplay.
    if (toastEnabled && System.currentTimeMillis() < toastUntil && mc.currentScreen instanceof ChatScreen) drawToast(ctx, mc);
    if (mc.world == null || mc.player == null || mc.currentScreen != null) return;
    float pt = tc.getTickDelta(true);
    for (Module m : MODULES) if (m.enabled) { try { m.onHud(ctx, pt); } catch (Throwable t) { fail(m, t); } }
    if (toastEnabled && System.currentTimeMillis() < toastUntil) drawToast(ctx, mc);
  }

  private static void drawToast(DrawContext ctx, MinecraftClient mc) {
    int sw = mc.getWindow().getScaledWidth();
    int w = Math.min(190, mc.textRenderer.getWidth(toastText) + 28);
    int x = toastX == Integer.MIN_VALUE ? (sw - w) / 2 : Math.max(0, Math.min(sw - w, toastX));
    int y = Math.max(0, Math.min(mc.getWindow().getScaledHeight() - 30, toastY));
    ctx.fill(x, y, x + w, y + 30, 0xE90A0A0A);
    ctx.fill(x, y, x + w, y + 1, 0xFF777777);
    ctx.fill(x, y + 29, x + w, y + 30, 0xFF333333);
    ctx.drawTextWithShadow(mc.textRenderer, toastText, x + 12, y + 11, 0xFFF0F0F0);
  }

  /** Lets the toast be repositioned with the mouse while the chat is open. */
  private static void updateToastDrag(MinecraftClient mc) {
    Module ui = byName("HUD");
    boolean allowed = ui != null && mc.currentScreen instanceof ChatScreen && toastUntil > System.currentTimeMillis();
    if (allowed) try { allowed = ui.get("Перемещение в чате").on(); } catch (Exception ignored) {}
    long handle = mc.getWindow().getHandle();
    boolean downNow = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
    if (!allowed) { toastDragging = false; toastMouseWasDown = downNow; return; }
    double scaleX = (double) mc.getWindow().getScaledWidth() / Math.max(1, mc.getWindow().getWidth());
    double scaleY = (double) mc.getWindow().getScaledHeight() / Math.max(1, mc.getWindow().getHeight());
    double rawX, rawY;
    try (MemoryStack stack = MemoryStack.stackPush()) {
      DoubleBuffer bx = stack.mallocDouble(1), by = stack.mallocDouble(1);
      GLFW.glfwGetCursorPos(handle, bx, by);
      rawX = bx.get(0); rawY = by.get(0);
    }
    double mx = rawX * scaleX;
    double my = rawY * scaleY;
    int w = Math.min(190, mc.textRenderer.getWidth(toastText) + 28);
    int x = toastX == Integer.MIN_VALUE ? (mc.getWindow().getScaledWidth() - w) / 2 : toastX;
    int y = toastY;
    if (downNow && !toastMouseWasDown && mx >= x && mx <= x + w && my >= y && my <= y + 30) {
      toastDragging = true; toastDragOffsetX = mx - x; toastDragOffsetY = my - y;
    }
    if (!downNow) toastDragging = false;
    if (downNow && toastDragging) {
      toastX = (int) Math.round(mx - toastDragOffsetX);
      toastY = (int) Math.round(my - toastDragOffsetY);
    }
    toastMouseWasDown = downNow;
  }

  public static void save() {
    try {
      JsonObject o = new JsonObject();
      for (Module m : MODULES) {
        JsonObject j = new JsonObject(); j.addProperty("enabled", m.enabled); j.addProperty("key", m.key);
        for (Setting s : m.settings) j.addProperty(s.name, s.value);
        o.add(m.name, j);
      }
      o.addProperty("__hudToastX", toastX);
      o.addProperty("__hudToastY", toastY);
      Files.writeString(CFG, new GsonBuilder().setPrettyPrinting().create().toJson(o));
    } catch (Exception e) { LOG.error("ZENIX: config save failed", e); }
  }

  static void load() {
    try {
      if (!Files.exists(CFG)) return;
      JsonObject o = JsonParser.parseString(Files.readString(CFG)).getAsJsonObject();
      if (o.has("__hudToastX")) toastX = o.get("__hudToastX").getAsInt();
      if (o.has("__hudToastY")) toastY = o.get("__hudToastY").getAsInt();
      for (Module m : MODULES) if (o.has(m.name)) {
        JsonObject j = o.getAsJsonObject(m.name);
        if (j.has("enabled") && !m.planned && !m.oneShot) m.enabled = j.get("enabled").getAsBoolean();
        if (j.has("key")) m.key = j.get("key").getAsInt();
        for (Setting s : m.settings) if (j.has(s.name)) s.set(j.get(s.name).getAsDouble());
      }
      // ClickGUI itself is always "on" (it only opens the screen)
      if (clickgui != null) clickgui.enabled = true;
    } catch (Exception e) { LOG.error("ZENIX: config load failed", e); }
  }
}
